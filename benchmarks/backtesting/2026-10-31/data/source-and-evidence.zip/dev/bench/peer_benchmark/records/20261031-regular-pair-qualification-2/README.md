# Regular quantitative PMwR/vectorbt qualification

Source a1629654; native pair sources2f39a913/57b2d4f7; installed ledgr891c23c8.
Eighteen native processes qualify nine cases:12x90,500x1260,all four scaling
shapes and actual N10/100/1000 independent session books per cold/warm arm.
Qualification clocks are never promoted. Native raw inputs/results remain
in the named TEMP ledgr-peer-ws5-* directories; attempts.json retains their
actual paths/source. All18 cold/warm financial diffs are empty, every real
changed-fill gut is detected with equity unchanged, and all session manifests
verify actual requested books. Existing PMwR financial controls are unchanged.

Pair cash/equity/holdings/decisions and fill keys/quantities match exactly in
all nine cases; cash/equity differences are zero. Reported prices differ.
No native price/accounting rewrite, forced full-fill parity or widened bound.
Exact decision comparisons use the declared common window through the
penultimate input pulse; final signals have no following fill.

headline_controls.rds,scaling_controls.rds,sessions_controls.rds feed the
existing measured-output checker. suite.rds is a validated qualification
seed with the eight native frameworks and116-assignment denominator; old
non-PMwR headline clocks remain, paired clocks are still pending. Old valid
PMwR clocks are retained unpooled in previous_pmwr. scaling_original/ is an
explicit70-row data view of the unchanged80-slot original window; all native
directories/source/phase samples remain original. Every archived PMwR native
financial hash is also checked. No raw timing record was edited or erased.

The first checker output (sibling20261031-regular-pair-qualification) stopped
after the small case: timed headline captures deliberately omit diagnostics.
It is partial/unpromoted. The corrected checker uses the existing traced
headline qualification and still demands its financial hash match the same
measured reference. No native run, expected value or oracle was changed.
prerequisite_N10 retains actual vectorbt10-book manifests and the cold-result
weak-reference control; its five native surfaces match the reviewed small
case exactly. The direct prerequisite is correctness only, not timing.

Expected independent reviewer: clean-context Codex ws5_close_review. Whole
WS5 and publication readiness remain open. Rotation, authoring recipes, custom
stateful callbacks and PIT capability are expressly outside this extension.
