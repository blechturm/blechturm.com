# WS5 scaling, stress, memory and research sessions

**Accepted preliminary WS5 evidence:** independent Codex Type1 PASS, round1,
no findings. [Review](../../../../../inst/design/ledgr_v0_2_3_spec_packet/cut3_workstream5_review.md).
Frozen product891c23c8; common unit SMA5/10 transition rule, zero costs,
USD10,000,000 opening cash. [Protocol](../../suite/protocol.md).

The current record has235 complete processes/470 validated arm clocks,
plus seven operator-unrun repeats. All ordinary headline/scaling cells have
five observations; stress has one descriptive observation per workflow.
The maintainer stopped the remaining N1000 ledgr repeats after the active
batch: durable3, ephemeral2, spot-FIFO3. All three assigned peer session
workflows have five repeats for each actual N10/100/1000 per arm. No process
was terminated.64/116 required assignments executed;52 later portfolio,
PIT and authoring assignments remain. This is preliminary suite evidence.

Warm seconds (medians; largest stress row is one observation, no ranking):

| Instruments x bars | ledgr durable | Ephemeral | Spot-FIFO | PMwR | vectorbt/Numba |
| --- | ---: | ---: | ---: | ---: | ---: |
|500x1260|22.50|14.28|11.08|0.270|0.1841|
|10x7200|10.68|8.85|10.23|0.140|0.0765|
|1166x252|11.31|5.81|3.89|0.270|0.1354|
|20x23400|45.81|40.47|60.11|0.570|0.2534|
|1166x7200, n=1|386.64|204.47|221.91|3.400|2.3311|

For1000 fresh tiny experiments, warm batch medians are621.08s durable(n3),
319.97s ephemeral(n2),338.06s spot-FIFO(n3),5.15s PMwR(n5),24.7828s
vectorbt(n5),35.7450s PyBroker(n5). These are actual batches, not projections
or one N-candidate sweep. The largest stress observation's warm sampled tree
private peaks are3.72GiB durable,6.27GiB PMwR and2.10GiB vectorbt; these
are sampled lower bounds for these workflows, not general engine limits.

Native controls match for every complete arm. Backtrader/quantstrat/vectorbt
qualify trades/balances; PMwR/PyBroker/bt remain decision-only and Zipline
retains its named residuals. All nine PMwR/vectorbt qualification cases have
exact paired cash/equity/holdings/decisions; reported prices differ. Reduced
sweeps have no full-output ratios. No N1000 ratio has five durable repeats.
Fresh six-workflow N10 scratch diff is empty; actual cash/DONE reuse,
cold-result retention, changed-fill, count and false-ratio guts pass.

PMwR/vectorbt ordinary first position alternates. Other historical framework
windows remain;15 valid older PMwR processes stay unpooled. Environment-loss
records preserve every failure and completed observation. The final main
session R/PyBroker windows are separate, not counterbalanced. Budget ledger:
19396.0832/21600s dense; conservative32011.4179/36000s scaling/sessions,
including the prior review reserve and900s final-verification precharge.
Source R1788+494 future=2282/2300; Python619+714=1333/2000; PS642/650.
Product/frozen paths are unchanged. Validation evidence is in validation/;
source windows/operator-stop metadata are alongside suite.rds.

[Rendered report](../../reports/20261031-ws5-observed/peer_suite.html).
