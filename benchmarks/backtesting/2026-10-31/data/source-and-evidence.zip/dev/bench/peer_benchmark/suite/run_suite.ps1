param(
  [Parameter(Mandatory=$true)][string]$Out,
  [ValidateSet('qualify','measure')][string]$Mode='qualify',
  [ValidateSet('dense','scaling','sessions')][string]$Lane='dense',
  [string]$QualifyShape='12x90',
  [double]$PriorLaneSeconds=0,
  [string]$StopFile='',
  [string]$OnlyShapes='',
  [string]$AttemptPrefix='',
  [string]$CompletedAttempts='',
  [string]$VectorbtPython='C:/Users/maxth/.cache/ledgr-peer-benchmark/vectorbt-ws5-20261031/Scripts/python.exe',
  [ValidateSet(14400,21600)][int]$DenseBudgetSeconds=14400,
  [ValidateSet('none','vectorbt')][string]$DiagnosticPair='none',
  [string[]]$OnlyEngines=@(),
  [string]$Inputs='C:/Users/maxth/AppData/Local/Temp/ledgr-peer-suite-cut3-normalized-inputs',
  [string]$Python='C:/Users/maxth/.cache/ledgr-peer-benchmark/native-python-ws5-20261031/Scripts/python.exe',
  [string]$Library='C:/Users/maxth/AppData/Local/Temp/ledgr-peer-suite-cut3-r-library-isolated',
  [string]$ProductLibrary='C:/Users/maxth/AppData/Local/Temp/ledgr-ws3-library-891c23c8'
)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'memory.ps1')
$Utf8=New-Object Text.UTF8Encoding($false)
$Rscript='C:/Program Files/R/R-4.6.1/bin/x64/Rscript.exe'
$Self=[Diagnostics.Process]::GetCurrentProcess()
$Self.ProcessorAffinity=[IntPtr]0xFFFF
$env:R_ENABLE_JIT='3'
$env:OMP_NUM_THREADS='1'
$env:OPENBLAS_NUM_THREADS='1'
$env:MKL_NUM_THREADS='1'
$env:NUMEXPR_NUM_THREADS='1'
$env:TZ='UTC'
$env:PYTHONHASHSEED='0'
$env:NUMBA_NUM_THREADS='1'
function Write-Json($Path,$Value) {
  [IO.File]::WriteAllText($Path,(ConvertTo-Json -InputObject $Value -Depth 12),$Utf8)
}
function Background-Load {
  $before=@{}
  Get-Process | Where-Object { $_.ProcessName -ne 'Idle' -and $null -ne $_.CPU } | ForEach-Object {
    try { $before[('{0}@{1}' -f $_.Id,$_.StartTime.ToUniversalTime().Ticks)]=$_.CPU } catch {}
  }
  $watch=[Diagnostics.Stopwatch]::StartNew()
  Start-Sleep -Seconds 2
  $activity=New-Object 'System.Collections.Generic.List[object]'
  Get-Process | Where-Object { $_.ProcessName -ne 'Idle' -and $null -ne $_.CPU } | ForEach-Object {
    try {
      $key='{0}@{1}' -f $_.Id,$_.StartTime.ToUniversalTime().Ticks
      if ($before.ContainsKey($key)) { $activity.Add([pscustomobject]@{ id=$key; name=$_.ProcessName; cpu_sec=[Math]::Max(0,$_.CPU-$before[$key]) }) }
    } catch {}
  }
  $script:BackgroundTop=@($activity | Where-Object cpu_sec -gt 0 | Sort-Object cpu_sec -Descending | Select-Object -First 5)
  ($activity | Measure-Object cpu_sec -Sum).Sum/$watch.Elapsed.TotalSeconds
}
function Get-HostState {
  $power=(powercfg /getactivescheme | Out-String).Trim()
  $other=@(Get-CimInstance Win32_Process | Where-Object {
    $_.Name -in @('R.exe','Rscript.exe','Rterm.exe','Rgui.exe','rsession.exe')
  } | Select-Object ProcessId,ParentProcessId,Name,CreationDate)
  [pscustomobject]@{ power_plan=$power; other_R=$other;
    valid=($power -match '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c') }
}
if (Test-Path -LiteralPath $Out) { throw 'Output must be new; no automatic overwrite/retry.' }
[void](New-Item -ItemType Directory -Path $Out)
$engines=@('ledgr','ledgr_ephemeral','ledgr_spot_fifo','quantstrat','pmwr','backtrader','bt','zipline','pybroker','vectorbt')
if ($DiagnosticPair -eq 'vectorbt') { $engines=@('pmwr','vectorbt') }
$shapes=if ($Mode -eq 'qualify') { @($QualifyShape) } else { @('500x1260') }
if ($Lane -eq 'scaling') { $shapes=@('10x7200','1166x252','20x23400','1166x7200') }
if ($Lane -eq 'sessions') {
  $shapes=if ($PSBoundParameters.ContainsKey('QualifyShape')) { @($QualifyShape) } else { @('12x90_N10','12x90_N100','12x90_N1000') }
}
if ($OnlyEngines.Count -eq 1) { $OnlyEngines=@($OnlyEngines[0] -split ',') }
if ($OnlyShapes) { $shapes=@($OnlyShapes -split ',') }
$assignments=@{
  '10x7200'=@('ledgr','pmwr','backtrader','vectorbt'); '1166x252'=@('ledgr','pmwr','pybroker','vectorbt');
  '20x23400'=@('ledgr','backtrader','pybroker','pmwr','vectorbt'); '1166x7200'=@('ledgr','backtrader','pybroker','pmwr','vectorbt')
}
$Root=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../../..'))
$HarnessRevision=(& 'C:/Program Files/Git/cmd/git.exe' -C $Root rev-parse HEAD).Trim()
$attempts=New-Object 'System.Collections.Generic.List[object]'
$retainedIds=New-Object 'System.Collections.Generic.List[string]'
if ($CompletedAttempts) {
  foreach ($item in (Get-Content -LiteralPath $CompletedAttempts -Raw | ConvertFrom-Json)) {
    if ($item.status -eq 'complete') {
      if ($item.mode -ne $Mode) { throw 'Retained observations must have the same measurement mode.' }
      $attempts.Add($item)
      $retainedIds.Add($item.id)
    }
  }
}
trap {
  if (-not $stopWindow) {
    Write-Json (Join-Path $Out 'unexpected_error.json') @{ error=$_.Exception.Message; stack=$_.ScriptStackTrace;
      current_id=$a.id; persisted_attempts=$attempts.Count; phase='harness'; source_product='891c23c8' }
  }
  break
}
$batch=[Diagnostics.Stopwatch]::StartNew()
$budget=if ($Lane -eq 'dense') { $DenseBudgetSeconds } else { 36000 }
$repetitions=if ($Mode -eq 'qualify') { 1 } else { 5 }
$stopWindow=$false
$stopReason="limit"
$censored=@{}
foreach ($shape in $shapes) {
  $iterations=if ($Lane -eq 'sessions') { [int]($shape -replace '^.*_N','') } else { 1 }
  $inputShape=$shape -replace '_N[0-9]+$',''
  $assigned=if ($Lane -eq 'sessions') { @('ledgr','pmwr','pybroker','vectorbt') } elseif ($assignments.ContainsKey($shape)) { $assignments[$shape] } else { $engines }
  if ($Lane -in @('scaling','sessions')) { $assigned=@('ledgr','ledgr_ephemeral','ledgr_spot_fifo')+@($assigned | Where-Object { $_ -ne 'ledgr' }) }
  if ($DiagnosticPair -eq 'vectorbt') { $assigned=@('pmwr','vectorbt') }
  if ($OnlyEngines.Count -gt 0) { $assigned=@($assigned | Where-Object { $_ -in $OnlyEngines }) }
  $limit=if ($shape -eq '1166x7200') { 7200 } else { 1200 }
  $reps=if ($shape -eq '1166x7200') { 1 } else { $repetitions }
  for ($rep=1; $rep -le $reps; $rep++) {
    $offset=($rep-1)%$assigned.Count
    $order=@($assigned[$offset..($assigned.Count-1)])
    if ($offset -gt 0) { $order+=@($assigned[0..($offset-1)]) }
    if ($rep%2 -eq 0 -and $assigned.Count -gt 2) { [array]::Reverse($order) }
    foreach ($engine in $order) {
      $framework=if ($engine -like 'ledgr*') { 'ledgr' } else { $engine }
      $workflow=switch ($engine) { 'ledgr_ephemeral' { 'ephemeral' }; 'ledgr_spot_fifo' { 'spot_fifo' }; default { 'durable' } }
      $id='{0}{1}_{2}_{3:00}' -f $AttemptPrefix,$shape,$engine,$rep
      if ($retainedIds.Contains($id)) { continue }
      $directory=Join-Path $Out $id
      $a=[ordered]@{ id=$id; engine=$framework; workflow=$workflow; shape=$shape; repetition=$rep;
        mode=$Mode; requested=$iterations; completed_cold=0; completed_warm=0; status='not_started'; directory=$directory; exit_code=-1;
        power_plan=''; affinity=0; background_before=0.0; background_after=0.0;
        elapsed_sec=0.0; root_pid=0; source_product='891c23c8'; harness_revision=$HarnessRevision;
        started_utc=[DateTime]::UtcNow.ToString('o'); sampler_interval_ms=250; host_policy='background_observed_v1';
        other_R_before=@(); other_R_during=@(); other_R_after=@(); background_top_before=@(); background_top_after=@();
        root_created_utc=''; sampler_gap_polls=0 }
      if ($StopFile -and (Test-Path -LiteralPath $StopFile)) { $stopWindow=$true; $stopReason='executor_requested_stop' }
      if ($stopWindow -or $censored.ContainsKey($shape+':'+$engine) -or ($PriorLaneSeconds+$batch.Elapsed.TotalSeconds) -ge $budget) {
        $a.status='unrun_after_'+$stopReason
        $attempts.Add($a)
        continue
      }
      if ($Mode -eq 'measure') {
        $hostState=Get-HostState
        $a.power_plan=$hostState.power_plan
        $a.background_before=Background-Load
        $a.background_top_before=$script:BackgroundTop
        $a.other_R_before=$hostState.other_R
        if (-not $hostState.valid) {
          $a.status='host_invalid'
          Write-Json (Join-Path $Out ($id+'.host_failure.json')) @{ phase='preflight'; host=$hostState; background=$a.background_before }
          $attempts.Add($a)
          $stopWindow=$true
          $stopReason='host_invalid'
          continue
        }
      }
      $isR=$framework -in @('ledgr','pmwr','quantstrat')
      $start=New-Object Diagnostics.ProcessStartInfo
      $start.FileName=if ($isR) { $Rscript } elseif ($framework -eq 'vectorbt') { $VectorbtPython } else { $Python }
      $script=Join-Path $PSScriptRoot $(if ($isR) { 'run.R' } else { 'python/record_io.py' })
      $start.Arguments='"{0}" --engine={1} "--input={2}" "--out={3}"' -f $script,$framework,(Join-Path $Inputs ($inputShape+'.csv')),$directory
      if ($isR) {
        $lib=if ($framework -eq 'ledgr') { $ProductLibrary } else { $Library }
        $start.Arguments='--vanilla '+$start.Arguments+(' "--library={0}" --workflow={1}' -f $lib,$workflow)
      }
      $start.Arguments+=' --iterations='+$iterations
      if ($Mode -eq 'qualify') { $start.Arguments+= $(if ($isR) { ' --trace=true' } else { ' --trace' }) }
      $launch=([double]([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()/1000)).ToString('R',[Globalization.CultureInfo]::InvariantCulture)
      $start.Arguments+=' --launch='+$launch
      $start.UseShellExecute=$false
      $start.CreateNoWindow=$true
      $start.RedirectStandardOutput=$true
      $start.RedirectStandardError=$true
      $watch=[Diagnostics.Stopwatch]::StartNew()
      try { $process=[Diagnostics.Process]::Start($start) } catch {
        $a.status='failed'
        $a.elapsed_sec=$watch.Elapsed.TotalSeconds
        Write-Json (Join-Path $Out ($id+'.launch_failure.json')) @{ phase='launch'; executable=$start.FileName; error=$_.Exception.Message }
        $attempts.Add($a)
        $stopWindow=$true
        $stopReason='failed_launch'
        continue
      }
      $a.root_pid=$process.Id
      $rootCreated=$process.StartTime.ToUniversalTime()
      $a.root_created_utc=$rootCreated.ToString('o')
      $a.affinity=$process.ProcessorAffinity.ToInt64()
      $stdout=$process.StandardOutput.ReadToEndAsync()
      $stderr=$process.StandardError.ReadToEndAsync()
      $samples=New-Object 'System.Collections.Generic.List[object]'
      $otherRSeen=@{}
      while (-not $process.HasExited) {
        $poll=[Diagnostics.Stopwatch]::StartNew()
        $phaseFile=Join-Path $directory 'phase.txt'
        $phase=Get-ObservedPhase $phaseFile
        $tree=@(Get-TreeMemory $process.Id $phase $rootCreated)
        if ($script:MemorySampleGap) { $a.sampler_gap_polls++ }
        foreach ($sample in $tree) { $samples.Add($sample) }
        if ($Mode -eq 'measure') {
          $violation=Get-HostViolation $tree $process.Id
          foreach ($r in $script:ForeignRSeen) { $otherRSeen[('{0}@{1:o}' -f $r.ProcessId,$r.CreationDate)]=$r }
          if ($null -ne $violation) {
            & taskkill /PID $process.Id /T /F | Out-Null
            $a.status='host_invalid'
            Write-Json (Join-Path $Out ($id+'.host_failure.json')) $violation
            break
          }
        }
        $treePrivate=($tree | Measure-Object private_bytes -Sum).Sum
        if ($watch.Elapsed.TotalSeconds -ge $limit -or ($PriorLaneSeconds+$batch.Elapsed.TotalSeconds) -ge $budget -or
            ($shape -eq '1166x7200' -and $treePrivate -gt 16GB)) {
          & taskkill /PID $process.Id /T /F | Out-Null
          $a.status='censored'
          break
        }
        Start-Sleep -Milliseconds ([Math]::Max(1,250-$poll.ElapsedMilliseconds))
      }
      $process.WaitForExit()
      foreach ($arm in @('cold','warm')) {
        $bookPath=Join-Path $directory ($arm+'_books.csv')
        if (Test-Path -LiteralPath $bookPath) { $a['completed_'+$arm]=@(Import-Csv -LiteralPath $bookPath).Count }
      }
      $a.other_R_during=@($otherRSeen.Values)
      $a.exit_code=$process.ExitCode
      $a.elapsed_sec=$watch.Elapsed.TotalSeconds
      if ($a.status -eq 'not_started') { $a.status=if ($process.ExitCode -eq 0) { 'complete' } else { 'failed' } }
      [IO.File]::WriteAllText((Join-Path $Out ($id+'.stdout.txt')),$stdout.GetAwaiter().GetResult(),$Utf8)
      [IO.File]::WriteAllText((Join-Path $Out ($id+'.stderr.txt')),$stderr.GetAwaiter().GetResult(),$Utf8)
      $samples.ToArray() | Export-Csv -NoTypeInformation -Path (Join-Path $Out ($id+'.memory.csv'))
      @(Get-MemoryPhases $samples.ToArray()) | Export-Csv -NoTypeInformation -Path (Join-Path $Out ($id+'.phases.csv'))
      if ($Mode -eq 'measure') {
        $a.background_after=Background-Load
        $a.background_top_after=$script:BackgroundTop
        $hostState=Get-HostState
        $a.other_R_after=$hostState.other_R
        if (-not $hostState.valid -or $a.affinity -ne 65535) {
          if ($a.status -ne 'host_invalid') {
            Write-Json (Join-Path $Out ($id+'.host_failure.json')) @{ phase='postflight'; host=$hostState; background=$a.background_after }
          }
          $a.status='host_invalid'
        }
      }
      $attempts.Add($a)
      Write-Json (Join-Path $Out 'attempts.json') @($attempts.ToArray())
      Write-Host $id $a.status $a.elapsed_sec
      if ($a.status -in @('failed','host_invalid')) { $stopWindow=$true; $stopReason=$a.status }
      if ($a.status -eq 'censored') { $censored[$shape+':'+$engine]=$true }
    }
  }
}
Write-Json (Join-Path $Out 'attempts.json') @($attempts.ToArray())
Write-Json (Join-Path $Out 'session.json') @{ mode=$Mode; lane=$Lane; elapsed_sec=$batch.Elapsed.TotalSeconds;
  budget_sec=$budget; prior_lane_sec=$PriorLaneSeconds; stopped=$stopWindow; host_policy='background_observed_v1'; source_product='891c23c8'; repetitions=$repetitions; threads='OMP=1;OPENBLAS=1;MKL=1;NUMEXPR=1' }

if ($stopWindow) { throw "Window stopped for disposition: $stopReason; all remaining slots are explicit." }
