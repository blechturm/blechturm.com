param(
  [Parameter(Mandatory=$true)][string]$Out,
  [string]$Root = 'C:/Users/maxth/ledgr-wt/ws3-peer-oracle',
  [string]$SourceRevision = '891c23c8'
)
$ErrorActionPreference = 'Stop'
$Rscript = 'C:/Program Files/R/R-4.6.1/bin/x64/Rscript.exe'
$Rexe = 'C:/Program Files/R/R-4.6.1/bin/x64/R.exe'
$Git = 'C:/Program Files/Git/cmd/git.exe'
$Here = $PSScriptRoot
$Utf8 = New-Object System.Text.UTF8Encoding($false)
function Write-Json($Path, $Value) {
  [IO.File]::WriteAllText($Path, (ConvertTo-Json -InputObject $Value -Depth 12), $Utf8)
}
function Other-R($Except = -1) {
  @(Get-Process -Name R,Rscript,Rterm,Rgui,rsession -ErrorAction SilentlyContinue |
    Where-Object { $_.Id -ne $Except }).Count
}
function Background-Load {
  $first = @{}
  Get-Process | Where-Object { $_.ProcessName -ne 'Idle' -and $null -ne $_.CPU } |
    ForEach-Object { $first[$_.Id] = $_.CPU }
  $watch = [Diagnostics.Stopwatch]::StartNew()
  Start-Sleep -Milliseconds 2000
  $seconds = 0.0
  Get-Process | Where-Object { $first.ContainsKey($_.Id) -and $null -ne $_.CPU } |
    ForEach-Object { $seconds += [Math]::Max(0.0, $_.CPU - $first[$_.Id]) }
  return $seconds / $watch.Elapsed.TotalSeconds
}
function Prepare-Tool($Exe, $Arguments, $Log) {
  $si = New-Object Diagnostics.ProcessStartInfo
  $si.FileName = $Exe
  $si.Arguments = $Arguments
  $si.UseShellExecute = $false
  $si.CreateNoWindow = $true
  $si.RedirectStandardOutput = $true
  $si.RedirectStandardError = $true
  $tool = New-Object Diagnostics.Process
  $tool.StartInfo = $si
  [void]$tool.Start()
  $output = $tool.StandardOutput.ReadToEndAsync()
  $errors = $tool.StandardError.ReadToEndAsync()
  $tool.WaitForExit()
  [IO.File]::WriteAllText($Log, ($output.GetAwaiter().GetResult() + $errors.GetAwaiter().GetResult()), $Utf8)
  if ($tool.ExitCode -ne 0) { throw "Preparation tool failed: $Exe; see $Log" }
}

if (Test-Path -LiteralPath $Out) { throw 'Use a new output directory; no overwrite or retry.' }
[void](New-Item -ItemType Directory -Path $Out)
$Self = [Diagnostics.Process]::GetCurrentProcess()
$Self.ProcessorAffinity = [IntPtr]0xFFFF
$env:R_ENABLE_JIT = '3'
$env:OMP_NUM_THREADS = '1'
$env:OPENBLAS_NUM_THREADS = '1'
$env:MKL_NUM_THREADS = '1'
$env:NUMEXPR_NUM_THREADS = '1'
$SourceRevision = (& $Git -C $Root rev-parse $SourceRevision).Trim()
$HarnessRevision = (& $Git -C $Root rev-parse HEAD).Trim()
$Work = Join-Path $env:TEMP ('ledgr-ws3-timing-' + [Guid]::NewGuid().ToString('N'))
[void](New-Item -ItemType Directory -Path $Work)
$Library = Join-Path $Work 'library'
$Inputs = Join-Path $Work 'inputs'
[void](New-Item -ItemType Directory -Path $Library)
$Power = (powercfg /getactivescheme | Out-String).Trim()
$Other = Other-R
Write-Json (Join-Path $Out 'preflight.json') @{
  source_revision=$SourceRevision; harness_revision=$HarnessRevision; power_plan=$Power;
  parent_affinity=$Self.ProcessorAffinity.ToInt64(); other_r=$Other; scratch=$Work
}
if ($Power -notmatch '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c' -or $Other -ne 0) {
  throw 'Host unavailable: need High performance and no other R session. No measured attempt started.'
}
# Installation and common-input generation are explicitly outside both clocks.
$Zip = Join-Path $Work 'source.zip'
$Source = Join-Path $Work 'source'
& $Git -C $Root archive --format=zip "--output=$Zip" $SourceRevision
if ($LASTEXITCODE -ne 0) { throw 'git archive failed' }
Expand-Archive -LiteralPath $Zip -DestinationPath $Source
Prepare-Tool $Rexe ('CMD INSTALL --no-multiarch "--library={0}" "{1}"' -f $Library,$Source) (Join-Path $Out 'installation.txt')
Prepare-Tool $Rscript ('--vanilla "{0}" --mode=prepare "--library={1}" "--out={2}"' -f (Join-Path $Here 'timing.R'),$Library,$Inputs) (Join-Path $Out 'preparation.txt')
$Attempts = New-Object System.Collections.Generic.List[object]
$Batch = [Diagnostics.Stopwatch]::StartNew()
$Stop = $false
for ($Rep = 1; $Rep -le 5 -and -not $Stop; $Rep++) {
  $Shapes = if ($Rep % 2 -eq 1) { @('12x90','500x1260') } else { @('500x1260','12x90') }
  foreach ($Shape in $Shapes) {
    $Id = '{0}_{1:00}' -f $Shape,$Rep
    $AttemptDir = Join-Path $Work $Id
    $LoadBefore = Background-Load
    $Power = (powercfg /getactivescheme | Out-String).Trim()
    $Other = Other-R
    $a = [ordered]@{
      id=$Id; shape=$Shape; repetition=$Rep; status='not_started'; exit_code=-1;
      source_revision=$SourceRevision; harness_revision=$HarnessRevision;
      library=$Library; scratch=$AttemptDir; power_plan=$Power;
      parent_affinity=$Self.ProcessorAffinity.ToInt64(); child_affinity=0; pid=0;
      other_r_before=$Other; other_r_during=0; other_r_after=0;
      background_core_before=$LoadBefore; background_core_after=0.0; max_background_core=1.0;
      threads='OMP=1;OPENBLAS=1;MKL=1;NUMEXPR=1'; configured_jit=3;
      started_utc=[DateTime]::UtcNow.ToString('o'); elapsed_sec=0.0
    }
    if ($Other -ne 0 -or $LoadBefore -gt 1.0 -or $a.parent_affinity -ne 65535 -or
        $Power -notmatch '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c' -or $Batch.Elapsed.TotalSeconds -ge 5400) {
      $a.status = 'host_or_budget_unavailable'
      $Attempts.Add($a)
      $Stop = $true
      break
    }
    $Start = New-Object Diagnostics.ProcessStartInfo
    $Start.FileName = $Rscript
    $Start.Arguments = '--vanilla "{0}" --mode=worker "--library={1}" "--out={2}" --source={3} --shape={4} --repetition={5} "--input={6}"' -f (Join-Path $Here 'timing.R'),$Library,$AttemptDir,$SourceRevision,$Shape,$Rep,(Join-Path $Inputs ($Shape+'.rds'))
    $Start.UseShellExecute = $false
    $Start.CreateNoWindow = $true
    $Start.RedirectStandardOutput = $true
    $Start.RedirectStandardError = $true
    $p = New-Object Diagnostics.Process
    $p.StartInfo = $Start
    $Launch = ([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() / 1000).ToString('R', [Globalization.CultureInfo]::InvariantCulture)
    $p.StartInfo.Arguments += " --launch=$Launch"
    $Watch = [Diagnostics.Stopwatch]::StartNew()
    [void]$p.Start()
    $a.pid = $p.Id
    $a.child_affinity = $p.ProcessorAffinity.ToInt64()
    $Stdout = $p.StandardOutput.ReadToEndAsync()
    $Stderr = $p.StandardError.ReadToEndAsync()
    $Limit = [Math]::Min(1200.0, 5400.0 - $Batch.Elapsed.TotalSeconds)
    while (-not $p.WaitForExit(1000)) {
      $a.other_r_during = [Math]::Max($a.other_r_during, (Other-R $p.Id))
      if ($Watch.Elapsed.TotalSeconds -ge $Limit -or $a.other_r_during -ne 0) {
        $p.Kill()
        $p.WaitForExit()
        $a.status = if ($a.other_r_during -ne 0) { 'host_invalid' } else { 'censored' }
        break
      }
    }
    $a.elapsed_sec = $Watch.Elapsed.TotalSeconds
    if ($a.status -eq 'not_started' -and $a.elapsed_sec -gt $Limit) { $a.status = 'censored' }
    $a.exit_code = $p.ExitCode
    if ($a.status -eq 'not_started') { $a.status = if ($p.ExitCode -eq 0) { 'complete' } else { 'failed' } }
    [IO.File]::WriteAllText((Join-Path $Out ($Id+'.stdout.txt')), $Stdout.GetAwaiter().GetResult(), $Utf8)
    [IO.File]::WriteAllText((Join-Path $Out ($Id+'.stderr.txt')), $Stderr.GetAwaiter().GetResult(), $Utf8)
    $a.other_r_after = Other-R
    $a.background_core_after = Background-Load
    if ($a.status -eq 'complete' -and ($a.child_affinity -ne 65535 -or $a.other_r_after -ne 0 -or $a.background_core_after -gt 1.0)) { $a.status = 'host_invalid' }
    $Attempts.Add($a)
    Write-Json (Join-Path $Out 'attempts.json') @($Attempts.ToArray())
    if (Test-Path -LiteralPath (Join-Path $AttemptDir 'environment.txt')) {
      Copy-Item -LiteralPath (Join-Path $AttemptDir 'environment.txt') -Destination (Join-Path $Out ($Id+'.environment.txt'))
    }
    Write-Host $Id $a.status $a.elapsed_sec
    if ($a.status -ne 'complete') { $Stop = $true; break }
  }
}
Write-Json (Join-Path $Out 'attempts.json') @($Attempts.ToArray())
Write-Json (Join-Path $Out 'session.json') @{ source_revision=$SourceRevision; harness_revision=$HarnessRevision; measurement_window_sec=$Batch.Elapsed.TotalSeconds; attempt_limit_sec=1200; repetitions=5 }
& $Rscript --vanilla (Join-Path $Here 'timing_check.R') "--collect=$Out"
if ($LASTEXITCODE -ne 0 -or $Stop) { throw 'Baseline incomplete/invalid; preserved every attempt; stop for disposition, no retry.' }
