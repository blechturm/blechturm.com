# Qualify the regular PMwR/vectorbt crossover pair; native facts, no execution surrogate.
file <- sub("^--file=","",grep("^--file=",commandArgs(FALSE),value=TRUE)[1L])
here <- dirname(normalizePath(file,winslash="/"))
source(file.path(here,"../dense/native.R"))
source(file.path(here,"records.R"),chdir=TRUE)
root <- normalizePath(file.path(here,"../../../.."),winslash="/")
before <- dense_scope(root)
out <- dense_arg("out")
stopifnot(!dir.exists(out))
dir.create(out,recursive=TRUE)
base <- readRDS(file.path(dense_arg("base"),"suite.rds"))
scaling <- readRDS(dense_arg("scaling-controls"))
sessions <- readRDS(dense_arg("session-controls"))
prior <- suite_rows(base$controls,suite_rows(scaling,sessions))
raw <- strsplit(dense_arg("qualification"),",",fixed=TRUE)[[1L]]
a <- do.call(rbind,lapply(raw,function(path) jsonlite::fromJSON(file.path(path,"attempts.json"))))
shapes <- c("12x90","500x1260","10x7200","1166x252","20x23400","1166x7200","12x90_N10","12x90_N100","12x90_N1000")
stopifnot(nrow(a)==18L,setequal(a$shape,shapes),all(a$status=="complete"),all(a$mode=="qualify"),all(a$workflow=="durable"),
  setequal(paste(a$shape,a$engine),as.vector(outer(shapes,c("pmwr","vectorbt"),paste))))
controls <- comparisons <- pair <- list()
for(shape in shapes) {
  input_shape <- sub("_N[0-9]+$","",shape)
  bars <- read.csv(file.path(dense_arg("inputs"),paste0(input_shape,".csv")))
  lane <- if(shape=="12x90") "dense_native" else if(shape=="500x1260") "headline" else if(grepl("_N",shape)) "sessions" else "scaling"
  reference <- if(input_shape=="12x90") base$native$ledgr else if(shape=="500x1260")
    suite_read(file.path(dense_arg("headline-reference"),"500x1260_ledgr_01")) else
    suite_read(file.path(dense_arg("reference"),paste0(shape,"_ledgr_01")))
  reference_control <- if(input_shape=="12x90") base$qualification_controls[["ledgr"]] else prior$control[match(paste(lane,shape,"ledgr","durable",sep=":"),prior$key)]
  stopifnot(identical(suite_control(reference,bars,"ledgr"),reference_control))
  reference$scores <- suite_scores(reference)
  financial <- results <- list()
  for(engine in c("pmwr","vectorbt")) {
    row <- a[a$shape==shape & a$engine==engine,]
    stopifnot(nrow(row)==1L)
    suite_books(row)
    cold <- suite_read(row$directory,engine=engine)
    warm <- suite_read(row$directory,"warm",engine)
    fields <- c("fills","equity","holdings","scores","intent")
    diff <- dense_diff(cold[fields],warm[fields],engine)
    write.csv(diff,file.path(out,paste0(shape,"_",engine,"_diff.csv")),row.names=FALSE)
    stopifnot(nrow(diff)==0L)
    control <- suite_control(cold,bars,engine)
    stopifnot(identical(control,suite_control(warm,bars,engine)))
    key <- paste(lane,shape,engine,"durable",sep=":")
    if(engine=="pmwr") stopifnot(identical(control,if(shape=="12x90") base$qualification_controls[[engine]] else prior$control[match(key,prior$key)]))
    controls[[length(controls)+1L]] <- data.frame(key=key,control=control)
    results[[engine]] <- data.frame(engine=engine,shape=shape,suite_compare(reference,cold,bars,engine),ratio_eligible=FALSE)
    comparisons[[length(comparisons)+1L]] <- results[[engine]]
    financial[[engine]] <- suite_financial(cold,bars,engine)
    if(engine=="vectorbt" && shape=="12x90") {
      base$native$vectorbt <- cold
      base$qualification_controls["vectorbt"] <- control
      base$provenance <- rbind(base$provenance,data.frame(engine=engine,native_directory=row$directory,reset_identical=TRUE,qualification_only=TRUE))
    }
    bad <- cold
    bad$fills$qty[1L] <- bad$fills$qty[1L]+1
    gut <- dense_diff(cold[fields],bad[fields],engine)
    stopifnot(identical(cold$equity,bad$equity),nrow(gut)>0L,!identical(control,suite_control(bad,bars,engine)))
    write.csv(gut,file.path(out,paste0(shape,"_",engine,"_gut.csv")),row.names=FALSE)
    rm(cold,warm,bad)
    invisible(gc())
  }
  p <- financial$pmwr
  v <- financial$vectorbt
  same_keys <- identical(p$fills[c("ts_utc","instrument_id","qty")],v$fills[c("ts_utc","instrument_id","qty")])
  pair[[shape]] <- data.frame(shape=shape,cash_exact=identical(p$equity$cash,v$equity$cash),
    equity_exact=identical(p$equity$equity,v$equity$equity),holdings_exact=identical(p$holdings,v$holdings),
    decisions_exact=all(vapply(results,function(x) x$intent_agreement && x$discrete_above_agreement,logical(1L))),
    fill_keys_quantities_exact=same_keys,reported_prices_exact=same_keys && identical(p$fills$price,v$fills$price),
    max_cash_difference=max(abs(p$equity$cash-v$equity$cash)),max_equity_difference=max(abs(p$equity$equity-v$equity$equity)))
  rm(bars,reference,financial,p,v)
  invisible(gc())
}
controls <- do.call(rbind,controls)
comparisons <- do.call(rbind,comparisons)
base$previous_pmwr <- list(reason="Valid historical clocks superseded only for the maintainer-requested balanced cohort; never pooled.",
  attempts=subset(base$attempts,engine=="pmwr"),timings=subset(base$timings,engine=="pmwr"),memory=subset(base$memory,engine=="pmwr"))
old <- jsonlite::fromJSON(file.path(dense_arg("original-scaling"),"attempts.json"))
for(i in which(old$engine=="pmwr")) for(arm in c("cold","warm")) {
  bars <- read.csv(file.path(dense_arg("inputs"),paste0(old$shape[i],".csv")))
  key <- paste("scaling",old$shape[i],"pmwr","durable",sep=":")
  stopifnot(identical(suite_control(suite_read(old$directory[i],arm,"pmwr"),bars,"pmwr"),scaling$control[match(key,scaling$key)]))
}
base$previous_pmwr$scaling_attempts <- subset(old,engine=="pmwr")
base$previous_pmwr$scaling_clocks <- stats::setNames(lapply(base$previous_pmwr$scaling_attempts$directory,
  function(path) jsonlite::fromJSON(file.path(path,"timing.json"))),base$previous_pmwr$scaling_attempts$id)
historical <- base$previous_pmwr
historical$clocks <- suite_rows(historical$timings[c("id","shape","arm","clock_sec")],do.call(rbind,Map(function(id,x)
  data.frame(id=id,shape=historical$scaling_attempts$shape[match(id,historical$scaling_attempts$id)],x[c("arm","clock_sec")]),names(historical$scaling_clocks),historical$scaling_clocks)))
base$previous_pmwr <- historical
dir.create(file.path(out,"scaling_original"))
jsonlite::write_json(subset(old,engine!="pmwr"),file.path(out,"scaling_original/attempts.json"),dataframe="rows",auto_unbox=TRUE,digits=NA,pretty=TRUE)
base$attempts <- subset(base$attempts,engine!="pmwr")
base$timings <- subset(base$timings,engine!="pmwr")
base$memory <- subset(base$memory,engine!="pmwr")
base$controls <- base$controls[!grepl(":pmwr:",base$controls$key),]
base$comparisons <- suite_rows(subset(base$comparisons,engine!="pmwr"),subset(comparisons,shape=="12x90"))
base$pair_comparisons <- do.call(rbind,pair)
base$assignments <- read.csv(suite_assignment_path)
base$id <- basename(out)
base$date <- as.character(Sys.Date())
executed <- 1L+vapply(names(base$native),function(engine) nrow(unique(base$attempts[base$attempts$engine==engine,c("shape","workflow")])),integer(1L))
executed[["ledgr"]] <- executed[["ledgr"]]+2L
base$coverage <- suite_coverage(base$assignments,base$comparisons,executed)
suite_validate(base,base$id)
saveRDS(base,file.path(out,"suite.rds"),version=3L)
for(lane in c("headline","scaling","sessions")) {
  existing <- switch(lane,headline=NULL,scaling=scaling,sessions=sessions)
  selected <- controls[startsWith(controls$key,paste0(lane,":")),]
  expected <- suite_rows(if(is.null(existing)) NULL else existing[!grepl(":pmwr:",existing$key),],selected)
  c <- suite_rows(if(is.null(existing)) NULL else subset(attr(existing,"comparisons"),engine!="pmwr"),comparisons[comparisons$shape %in% base$assignments$shape[base$assignments$lane==lane],])
  attr(expected,"comparisons") <- c
  stopifnot(!anyDuplicated(expected$key))
  saveRDS(expected,file.path(out,paste0(lane,"_controls.rds")),version=3L)
}
write.csv(comparisons,file.path(out,"comparisons.csv"),row.names=FALSE)
write.csv(base$pair_comparisons,file.path(out,"pair_comparisons.csv"),row.names=FALSE)
jsonlite::write_json(a,file.path(out,"attempts.json"),dataframe="rows",auto_unbox=TRUE,digits=NA,pretty=TRUE)
stopifnot(identical(before,dense_scope(root)))
cat("PASS: regular pair native controls, exact state/fill-price fields, independent books and changed-fill guts.\n")
