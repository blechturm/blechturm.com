# Native peer differences: executed findings, 2026-10-29

Small fixture:12x90,common8-decimal prices,USD10m opening cash,unit quantities.
Source product891c23c8; executed fork1acdb21b; record
`records/20261028-cut3-normalized-qualification-v2/suite.rds`.
Readability of the report: show economic magnitude and cause before technical
labels. Opening cash deliberately removes funding constraints; positions are
one share. Ledgr terminal profit16.978217633 USD is not a realistic fully invested
USD10m portfolio. These figures are qualification observations, not speed claims.

| Peer | Terminal equity difference USD | Maximum equity gap USD | Cause / status |
| --- | ---: | ---: | --- |
| quantstrat | 0.00000000745 | 0.00000001118 | Inside fixed floating-point bound; full native comparison qualifies. |
| backtrader | 0 | 0 | Full native comparison qualifies. |
| PMwR | 0.00000000559 | 0.00000000745 | Balances/holdings agree; native journal reports close prices despite open execution. |
| PyBroker | 0.00000000745 | 0.00000001118 | Balances/holdings/prices agree; native sells precede buys within a pulse. |
| bt | 3.3468881659 | 4.0890063364 | Native current-close workflow, versus next-open fills; temporary cash gap390.7860184852. |
| Zipline | -1.9652176276 | 18.6512781791 | Native next-close execution and daily-bundle0.001 price precision. |

PMwR1.3-0 installed btest body assigns journal prices from mC[ic,cc], while
the execution branch uses mO[t,] when trade.at.open=TRUE. Native P05 first buy
2020-01-16: journal74.23009787 equals close; actual cash falls74.2106446903199,
matching open74.21064469 within roundoff. This is an upstream journal defect,
not a different price-setting argument or adapter-owned correction. Public
source: https://search.r-project.org/CRAN/refmans/PMwR/html/btest.html .

PyBroker2.0.2 installed strategy.py:919--943 places sells before buys. First
observed order difference2020-02-05: ledgr P02 buy,P09 sell,P11 buy; PyBroker
P09 sell,P02 buy,P11 buy. Do not reorder native within-pulse events into agreement.
Source: https://github.com/edtechre/pybroker/blob/master/src/pybroker/strategy.py .

bt1.4.1 Strategy.transact uses its current Security price. The pinned workflow
therefore buys P05 at2020-01-15 close, while ledgr buys next input open. This is
native execution convention, not an SMA/warmup mismatch. Source:
https://pmorissette.github.io/bt/docs/source/overview.html .

Zipline3.2.1 installed bcolz_daily_bars.py:345 rounds OHLC*1000 into uint32.
Its default zero-spread daily slippage uses the next close. Neither issue is
fixed by changing common8-decimal input normalization or moving timestamps.
Source: https://zipline.ml4trading.io/bundles.html .

The remembered final trade is recorded in inst/design/horizon_archive.md,
2026-09-18 peer-alignment defect: shifted24/5 labels plus341 final liquidations.
Native auto_close_date liquidates at its stated date; csvdir.py:237 defaults
end_date+1 calendar day. A controlled native P11 probe changed only metadata:
auto-close after end gives5 fills and1 held share; auto-close at end gives6
fills and0 shares. Native target intent is unchanged, with no final sell.
The current new adapter places auto-close after run end; that liquidation is
absent. The probe demonstrates the mechanism, not an exact reproduction of
all341 historical trades. Source:
https://zipline.ml4trading.io/api-reference.html (Asset.auto_close_date).
Reproduction is suite/python/record_io.py --engine=zipline --probe=terminal
with the common12x90 input, explicit new --out and --launch=0 (untimed probe).

Large validation completed ledgr,quantstrat,PMwR,backtrader,bt. It was stopped
during Zipline after discovering the separate WS1 timing window. PyBroker
was unstarted. All outputs remain at TEMP/ledgr-peer-suite-cut3-large-validation-1,
including interruption.json. No validation-process clock is promoted as warm
performance; none includes a valid isolated-host claim. Remaining timings,
scaling, sessions and independent workstream reviews remain outstanding.
