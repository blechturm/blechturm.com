"""backtrader 1.9.78.123: native SMA, market orders, broker result observations."""
import backtrader as bt
import numpy as np
import pandas as pd

REUSE = "immutable per-symbol OHLC frames only; new Cerebro, feeds, indicators and broker each arm"

def prepare(bars, out):
    return {name: frame.set_index("ts_utc")[["open", "high", "low", "close", "volume"]]
            for name, frame in bars.groupby("instrument_id", sort=True)}

def run(prepared, trace=False):
    class Crossover(bt.Strategy):
        def __init__(self):
            self.fast = [bt.ind.SMA(d.close, period=5) for d in self.datas]
            self.slow = [bt.ind.SMA(d.close, period=10) for d in self.datas]
            self.previous = [None] * len(self.datas)
            self.fills, self.equity, self.holding_rows, self.scores, self.intent = [], [], [], [], []
            self.decision = {}
        def notify_order(self, order):
            if order.status == order.Completed:
                self.fills.append((bt.num2date(order.executed.dt).isoformat(), order.data._name,
                    order.executed.size, order.executed.price, order.executed.comm,
                    self.decision.pop(order.ref)))
            elif order.status in (order.Margin, order.Rejected):
                raise RuntimeError("native order rejected")
        def prenext(self):
            self.next()
        def next(self):
            stamp = self.datetime.datetime().isoformat()
            self.equity.append((stamp, self.broker.getcash(), self.broker.getvalue()))
            self.holding_rows.append([self.getposition(d).size for d in self.datas])
            for i, data in enumerate(self.datas):
                fast, slow = self.fast[i][0], self.slow[i][0]
                usable = np.isfinite(fast) and np.isfinite(slow)
                above = fast > slow if usable else None
                if trace:
                    self.scores.append((stamp, data._name, fast, slow))
                previous = self.previous[i]
                if usable and previous is not None and above != previous:
                    target = int(above)
                    order = self.order_target_size(data=data, target=target)
                    if order is not None:
                        self.decision[order.ref] = stamp
                    if trace:
                        self.intent.append((stamp, data._name, target))
                self.previous[i] = above
    cerebro = bt.Cerebro(stdstats=False)
    cerebro.broker.setcash(1e7)
    cerebro.broker.setcommission(commission=0)
    for name, frame in prepared.items():
        cerebro.adddata(bt.feeds.PandasData(dataname=frame), name=name)
    cerebro.addstrategy(Crossover)
    native = cerebro.run()[0]
    equity = pd.DataFrame(native.equity, columns=["ts_utc", "cash", "equity"])
    holdings = pd.DataFrame(native.holding_rows, columns=prepared.keys())
    holdings.insert(0, "ts_utc", equity.ts_utc)
    return dict(fills=pd.DataFrame(native.fills, columns=["ts_utc", "instrument_id", "qty", "price", "fee", "decision_ts"]),
                equity=equity, holdings=holdings,
                scores=pd.DataFrame(native.scores, columns=["ts_utc", "instrument_id", "fast", "slow"]) if trace else None,
                intent=pd.DataFrame(native.intent, columns=["ts_utc", "instrument_id", "target"]) if trace else None)
