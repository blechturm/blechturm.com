# Common public input preparation, outside all clocks; no expected outcomes.
args <- commandArgs(TRUE)
.libPaths(c(args[1L],.libPaths()))
suppressPackageStartupMessages(library(ledgr))
shape <- strsplit(args[2L],"x",fixed=TRUE)[[1L]]
I <- as.integer(shape[1L])
S <- as.integer(shape[2L])
dir.create(dirname(args[4L]),recursive=TRUE,showWarnings=FALSE)
bars <- ledgr_sim_bars(I,S,seed=20260530L,start="2020-01-01",instrument_prefix="P")
if(args[3L]=="scaling") {
  bars$low <- pmin(bars$low,bars$open,bars$close)
  for(name in c("open","high","low","close")) bars[[name]] <- 100+log(bars[[name]])
}
for(name in c("open","high","low","close","volume")) bars[[name]] <- round(bars[[name]],8L)
stopifnot(all(is.finite(as.matrix(bars[c("open","high","low","close")]))),
  min(as.matrix(bars[c("open","high","low","close")]))>0,
  all(bars$high>=pmax(bars$open,bars$close)),all(bars$low<=pmin(bars$open,bars$close)))
if(args[3L]=="scaling") {
  path <- as.vector(rbind(bars$open,bars$close))
  boundaries <- rep(seq_len(I),each=2L*S)
  V <- sum(abs(diff(path))[diff(boundaries)==0L])
  G <- I*max(path)
  stopifnot(2*(G+V)<1e7)
  saveRDS(data.frame(shape=args[2L],instruments=I,pulses=S,G=G,V=V,bound=2*(G+V),cash=1e7),paste0(args[4L],".funding.rds"),version=3L)
}
if(args[2L]=="20x23400") {
  days <- sort(unique(bars$ts_utc))[seq_len(60L)]
  stamps <- rep(days,each=390L)+rep((14L*60L+31L+0:389)*60L,60L)
  bars$ts_utc <- stamps[match(bars$ts_utc,sort(unique(bars$ts_utc)))]
} else bars$ts_utc <- bars$ts_utc+21*3600
bars$ts_utc <- format(bars$ts_utc,"%Y-%m-%dT%H:%M:%SZ",tz="UTC")
for(name in c("open","high","low","close","volume")) bars[[name]] <- sprintf("%.17g",bars[[name]])
write.table(bars,args[4L],sep=",",row.names=FALSE,quote=FALSE)
