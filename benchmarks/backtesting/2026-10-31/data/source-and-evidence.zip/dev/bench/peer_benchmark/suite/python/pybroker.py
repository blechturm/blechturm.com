"""PyBroker v2 native delayed orders and unrounded native histories."""
import numpy as np
import pandas as pd
import pybroker as pb

REUSE = "unchanged native input DataFrame; new Strategy, session dictionaries and portfolio each arm"

def prepare(bars, out):
    data = bars.rename(columns={"instrument_id": "symbol", "ts_utc": "date"}).copy()
    data["date"] = data.date.dt.tz_localize(None)
    return data

def run(prepared, trace=False):
    scores, intent = [], []
    def crossover(ctx):
        close = ctx.close
        usable = len(close) >= 10
        fast = np.mean(close[-5:]) if len(close) >= 5 else np.nan
        slow = np.mean(close[-10:]) if usable else np.nan
        above = bool(fast > slow) if usable else None
        prior = ctx.session.get("above")
        stamp = pd.Timestamp(ctx.dt).isoformat()
        if trace:
            scores.append((stamp, ctx.symbol, fast, slow))
        if usable and prior is not None and above != prior:
            if above and ctx.long_pos() is None:
                ctx.buy_shares, ctx.buy_fill_price = 1, pb.PriceType.OPEN
            elif not above and ctx.long_pos() is not None:
                ctx.sell_shares, ctx.sell_fill_price = 1, pb.PriceType.OPEN
            if trace:
                intent.append((stamp, ctx.symbol, int(above)))
        ctx.session["above"] = above
    config = pb.StrategyConfig(initial_cash=1e7, buy_delay=1, sell_delay=1,
        round_fill_price=False, round_test_result=False, exit_on_last_bar=False,
        record_portfolio_bars=True, record_position_bars=True)
    strategy = pb.Strategy(prepared, prepared.date.min(), prepared.date.max(), config=config)
    strategy.add_execution(crossover, prepared.symbol.unique())
    result = strategy.backtest(warmup=None, parallel_indicators=False, parallel_models=False)
    orders = result.orders.reset_index()
    fills = pd.DataFrame(dict(ts_utc=orders.date, instrument_id=orders.symbol,
        qty=np.where(orders.type.str.lower()=="buy",1,-1)*orders.shares,
        price=orders.fill_price, fee=orders.fees))
    equity = result.portfolio.reset_index().rename(columns={"date":"ts_utc"})
    positions = result.positions.reset_index()
    holdings = positions.pivot(index="date", columns="symbol", values="long_shares").fillna(0)
    holdings = holdings.reindex(index=equity.ts_utc, columns=sorted(prepared.symbol.unique()), fill_value=0).fillna(0)
    holdings.index.name="ts_utc"
    return dict(fills=fills, equity=equity[["ts_utc","cash","equity"]], holdings=holdings.reset_index(),
        scores=pd.DataFrame(scores, columns=["ts_utc","instrument_id","fast","slow"]) if trace else None,
        intent=pd.DataFrame(intent, columns=["ts_utc","instrument_id","target"]) if trace else None)
