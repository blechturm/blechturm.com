# Restore every locked dependency into the explicit library; no ambient user/site packages.
lib <- normalizePath(commandArgs(TRUE)[1L],winslash="/",mustWork=FALSE)
dir.create(lib,recursive=TRUE,showWarnings=FALSE)
.libPaths(c(lib,.Library),include.site=FALSE)
file <- sub("^--file=","",grep("^--file=",commandArgs(FALSE),value=TRUE)[1L])
lock <- read.csv(file.path(dirname(normalizePath(file)),"r_requirements.csv"))
for(i in seq_len(nrow(lock))) {
  archive <- file.path(tempdir(),paste0(lock$package[i],"_",lock$version[i],if(lock$type[i]=="source") ".tar.gz" else ".zip"))
  download.file(lock$url[i],archive,mode="wb",quiet=TRUE)
  install.packages(archive,lib=lib,repos=NULL,type=lock$type[i],INSTALL_opts="--preclean")
}
actual <- installed.packages(lib.loc=lib)[lock$package,"Version"]
stopifnot(identical(unname(actual),lock$version))
write.csv(installed.packages(lib.loc=.libPaths())[,c("Package","Version","LibPath")],
  file.path(lib,"environment.csv"),row.names=FALSE)
writeLines(capture.output(sessionInfo()),file.path(lib,"session.txt"))
