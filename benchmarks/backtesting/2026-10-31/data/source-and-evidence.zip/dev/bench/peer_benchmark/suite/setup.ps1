param(
  [Parameter(Mandatory=$true)][string]$Environment,
  [Parameter(Mandatory=$true)][string]$Library
)
$ErrorActionPreference = 'Stop'
$Python = Join-Path $Environment 'Scripts/python.exe'
if (-not (Test-Path -LiteralPath $Python)) {
  & uv venv --python 3.12.13 $Environment
  if ($LASTEXITCODE -ne 0) { throw 'Python environment creation failed' }
}
& uv pip sync --python $Python (Join-Path $PSScriptRoot 'python/requirements.lock')
if ($LASTEXITCODE -ne 0) { throw 'Native dependency resolution/install failed' }
& $Python -c 'import backtrader, bt, zipline, pybroker; print("Native imports qualified")'
if ($LASTEXITCODE -ne 0) { throw 'Native imports failed; do not assume dependency compatibility' }
& 'C:/Program Files/R/R-4.6.1/bin/x64/Rscript.exe' --vanilla (Join-Path $PSScriptRoot 'setup.R') $Library
if ($LASTEXITCODE -ne 0) { throw 'Native R provisioning failed' }
& uv pip freeze --python $Python
