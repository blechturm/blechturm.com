# PMwR btest OHLC workflow; native histories and transaction journal.
suite_prepare <- function(bars, out) {
  ids <- sort(unique(bars$instrument_id), method = "radix")
  times <- sort(unique(bars$ts_utc))
  index <- match(bars$ts_utc, times) + (match(bars$instrument_id, ids)-1L)*length(times)
  prices <- lapply(c("open", "high", "low", "close"), function(name) {
    value <- matrix(NA_real_, length(times), length(ids), dimnames=list(NULL,ids))
    value[index] <- bars[[name]]
    value
  })
  list(prices=prices, times=times, ids=ids)
}
suite_run <- function(prepared, trace=FALSE) {
  close <- prepared$prices[[4L]]
  fast <- apply(close, 2L, TTR::SMA, n=5L)
  slow <- apply(close, 2L, TTR::SMA, n=10L)
  above <- fast > slow
  signal <- function() {
    t <- Time()
    target <- Portfolio()
    if (t > 1L) {
      usable <- is.finite(fast[t,]) & is.finite(slow[t,]) & is.finite(fast[t-1L,]) & is.finite(slow[t-1L,])
      change <- usable & above[t,] != above[t-1L,]
      target[change] <- as.numeric(above[t,change])
    }
    target
  }
  native <- PMwR::btest(prepared$prices, signal, timestamp=prepared$times,
    instrument=prepared$ids, initial.cash=1e7, initial.position=0, b=1L, lag=1L,
    tc=0, trade.at.open=TRUE, final.position=FALSE, include.data=FALSE)
  j <- as.data.frame(PMwR::journal(native))
  fills <- data.frame(ts_utc=j$timestamp,instrument_id=j$instrument,qty=j$amount,price=j$price,fee=0)
  equity <- data.frame(ts_utc=native$timestamp,cash=native$cash,equity=native$wealth)
  holdings <- data.frame(ts_utc=native$timestamp,native$position,check.names=FALSE)
  suggested <- if(trace) native$suggested.position[-1L,,drop=FALSE]
  changes <- if(trace) which(suggested!=native$position[-nrow(close),,drop=FALSE],arr.ind=TRUE)
  list(fills=fills,equity=equity,holdings=holdings,
    scores=if(trace) data.frame(ts_utc=rep(prepared$times,length(prepared$ids)),instrument_id=rep(prepared$ids,each=length(prepared$times)),fast=c(fast),slow=c(slow)),
    intent=if(trace) data.frame(ts_utc=prepared$times[changes[,1]],instrument_id=prepared$ids[changes[,2]],target=as.numeric(suggested[changes])))
}
