# Why PMwR and bt are faster on the headline fixture

**Answer:** their dense numeric workflows are lean; ledgr spends substantial
measured work on event/FIFO accounting and result reconstruction. The diagnosis
also exposed a benchmark lifecycle defect: the reported durable8.33s warm median
reopened a completed run. That figure is withdrawn, not optimized or replaced.

The unchanged500x1260 SMA5/10 rule ran on installed product891c23c8 and pinned
PMwR1.3-0/bt1.4.1. Exact native financial controls, two distinct ledgr IDs with
1260 native state rows each, scratch diff and actual cached-run/changed-fill
guts pass. [Evidence and reproduction](../records/20261029-speed-diagnosis/README.md).

| Work in the fresh diagnostic | ledgr | PMwR |
| --- | ---: | ---: |
| Experiment declaration |0.04s|included below|
| Public run / btest |21.50s|0.23s|
| Both SMA calculations |inside run|0.09s|
| Public fill reader |4.24s|journal/projection <0.01s timer resolution|
| Extra terminal-state reconstruction |4.50s|absent|
| Other required projections / cleanup |0.23s|0.04s|
| Total profiled elapsed |30.51s|0.36s|

Scratch reproduced29.62s and0.39s, with identical economics. These are profiles,
not controlled replacement medians. The earlier PMwR0.26s and bt4.42s medians
still describe their completed fresh warm runs; output/execution qualifications
remain unchanged. Cold includes CSV input/native ETL. Warm excludes that reusable
preparation but includes indicators, new book, execution and required outputs.

**PMwR:** four contiguous OHLC matrices total20.16MB; both SMA series are
recomputed inside warm. Installed btest uses an R time loop and vector/matrix
arithmetic, including portfolio wealth from positions, prices and cash. It
retains numeric position/cash/wealth histories and a journal, without ledgr's
per-fill FIFO event replay or canonical JSON records. R itself is not the limit.

**bt:** the installed core is core.cp312-win_amd64.pyd (Cython). The profile
observes1260 actual signal calls,3.67s inclusive in the callback, with substantial
Pandas slicing/reductions. Its compiled portfolio machinery and native history
arrays avoid ledgr's event-replay reader costs; current-close execution still
differs from ledgr. No cached-signal explanation fits either peer.

**ledgr:** disjoint classification of980 sampled R stacks assigns37.9% to lot
operations/accounting replay and17.3% to canonical JSON outside that group.
These are sampled main-R-thread CPU shares, not wall fractions. Public fill
reading and explicit state reconstruction independently replay accounting
(backtest-results.R -> backtest-fills.R; public-api.R -> accounting-replay.R). The latter
exists solely for an adapter correctness assertion, yet is inside its clock.
PIT is inactive on this dense workload; the profile does not justify attributing
the whole gap to PIT guarantees.

**Disposition:** explicit cold/warm run IDs and native decision counts now guard
fresh execution; the lifecycle gut rejects DONE-run reuse. The frozen cut2
worker already uses distinct IDs and is unaffected. Before new rankings, fix
and review the adapter clock boundary for the extra recovery assertion, then
rerun the invalid durable measurements under an accepted window. Product work
should first examine repeated result replay, then typed/indexed FIFO operations
and batched event serialization, preserving one fold and exact native semantics.
No product optimization, full-window retry or external performance claim was made.
