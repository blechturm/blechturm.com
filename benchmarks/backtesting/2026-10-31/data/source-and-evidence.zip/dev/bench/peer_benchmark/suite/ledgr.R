# Installed public ledgr; no internal handler API or alternative reconstruction.
source(file.path(here,"../dense/recipes.R"))
suite_prepare <- function(csv_path,out) {
  ledgr_snapshot_from_csv(csv_path,db_path=file.path(out,"snapshot.duckdb"),
    snapshot_id="suite_transition",price_basis="split_adjusted")
}
suite_run <- function(prepared,trace=FALSE,opening_cash=1e7,workflow="durable",run_id=NULL) {
  strategy <- dense_transition
  if(trace) body(strategy) <- substitute({
    result <- BODY
    result$state_update$targets <- as.list(result$targets)
    result$state_update$fast <- lapply(stats::setNames(ctx$vec$feature("fast"),ctx$universe),function(x) if(is.na(x)) NULL else x)
    result$state_update$slow <- lapply(stats::setNames(ctx$vec$feature("slow"),ctx$universe),function(x) if(is.na(x)) NULL else x)
    result
  },list(BODY=body(dense_transition)))
  exp <- ledgr_experiment(prepared,strategy,features=ledgr_feature_map(
    fast=ledgr_ind_ttr("SMA",input="close",id="fast",n=5L),
    slow=ledgr_ind_ttr("SMA",input="close",id="slow",n=10L)),
    opening=ledgr_opening(cash=opening_cash),cost_model=ledgr_cost_zero(),risk_chain=ledgr_risk_none())
  if(workflow!="durable") {
    candidate <- suppressWarnings(ledgr_sweep(exp,do.call(ledgr_grid_named,stats::setNames(list(list()),run_id)),
      retain=ledgr_sweep_retention(returns="completed",trades="closed"),workers=1L,
      seed=20260530L,stop_on_error=TRUE,
      compiled_accounting_model=if(workflow=="spot_fifo") "spot_fifo" else NULL))
    stopifnot(nrow(candidate)==1L,candidate$status=="DONE")
    returns <- as.data.frame(ledgr_sweep_returns(candidate))
    trades <- as.data.frame(ledgr_sweep_trades(candidate))
    return(list(equity=returns[c("ts_utc","equity")],
      closed_trades=trades[c("close_ts_utc","realized_pnl")],
      identity=data.frame(run_id=candidate$candidate_id,returned_pulses=nrow(returns),
        execution_seed=candidate$execution_seed,t_engine=candidate$t_engine)))
  }
  bt <- suppressWarnings(ledgr_run(exp,run_id=run_id,seed=20260530L))
  on.exit(close(bt),add=TRUE)
  f <- as.data.frame(ledgr_results(bt,"fills"))
  equity <- as.data.frame(ledgr_results(bt,"equity"))
  con <- ledgr_db_init(bt$db_path)
  on.exit(DBI::dbDisconnect(con,shutdown=TRUE),add=TRUE)
  fills <- data.frame(ts_utc=as.POSIXct(f$ts_utc,tz="UTC"),instrument_id=f$instrument_id,
    qty=ifelse(f$side=="BUY",f$qty,-f$qty),price=f$price,fee=f$fee,
    recording_pulse=f$recording_pulse_ts_utc)
  equity$ts_utc <- as.POSIXct(equity$ts_utc,tz="UTC")
  # Required per-pulse quantities are a native-ledger projection, not a fill/accounting engine.
  holdings <- DBI::dbGetQuery(con,paste(
    "WITH movement AS (SELECT ts_utc,instrument_id,",
    "SUM(CASE WHEN side='BUY' THEN qty ELSE -qty END) OVER",
    "(PARTITION BY instrument_id ORDER BY ts_utc,event_seq) AS qty",
    "FROM ledger_events WHERE run_id=? AND event_type='FILL')",
    "SELECT a.ts_utc,a.instrument_id,COALESCE(m.qty,0) AS qty",
    "FROM snapshot_bars a ASOF LEFT JOIN movement m",
    "ON a.instrument_id=m.instrument_id AND a.ts_utc>=m.ts_utc",
    "ORDER BY a.ts_utc,a.instrument_id"),params=list(bt$run_id))
  list(fills=fills,equity=equity[c("ts_utc","cash","equity")],holdings=holdings,
    closed_trades=data.frame(close_ts_utc=f$ts_utc[f$action=="CLOSE"],realized_pnl=f$realized_pnl[f$action=="CLOSE"]),
    state=if(trace) DBI::dbGetQuery(con,"SELECT ts_utc,state_json FROM strategy_state WHERE run_id=? ORDER BY ts_utc",params=list(bt$run_id)),identity=data.frame(
      run_id=bt$run_id,
      state_rows=DBI::dbGetQuery(con,"SELECT COUNT(*) AS n FROM strategy_state WHERE run_id=?",params=list(bt$run_id))$n,
      snapshot_hash=ledgr_snapshot_info(prepared)$snapshot_hash,
      duckdb_threads=DBI::dbGetQuery(con,"SELECT current_setting('threads') AS n")$n,
      config_hash=DBI::dbGetQuery(con,"SELECT config_hash FROM runs WHERE run_id=?",params=list(bt$run_id))$config_hash))
}

# Full recovery is an untimed correctness check, after both native arms finish.
suite_validate_terminal <- function(prepared,native) {
  clone <- tempfile("recovery_check_",tmpdir=dirname(prepared$db_path),fileext=".duckdb")
  stopifnot(file.copy(prepared$db_path,clone))
  con <- ledgr_db_init(clone)
  on.exit({DBI::dbDisconnect(con,shutdown=TRUE); unlink(clone)},add=TRUE)
  rebuilt <- ledgr_state_reconstruct(native$identity$run_id,con)$positions
  last <- tail(native$holdings,length(unique(native$holdings$instrument_id)))
  qty <- last$qty[match(rebuilt$instrument_id,last$instrument_id)]
  stopifnot(identical(as.numeric(qty),as.numeric(rebuilt$qty)))
}
