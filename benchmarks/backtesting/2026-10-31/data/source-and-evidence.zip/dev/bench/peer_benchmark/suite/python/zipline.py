"""Zipline Reloaded native daily bundle and order_target workflow."""
import os
from datetime import time
import numpy as np
import pandas as pd
import exchange_calendars as calendars
from exchange_calendars import ExchangeCalendar
from zipline import run_algorithm
from zipline.api import symbol, order_target, set_commission, set_slippage, get_datetime
from zipline.data.bundles import register, ingest
from zipline.finance.commission import PerShare
from zipline.finance.slippage import FixedSlippage

REUSE = "unchanged ingested native daily bundle/calendar; new TradingAlgorithm and portfolio each arm"

class SyntheticWeekdays(ExchangeCalendar):
    name = "LEDGR_SYNTHETIC"
    tz = "UTC"
    open_times = ((None, time(14,30)),)
    close_times = ((None, time(21,0)),)

def prepare(bars, out, auto_close_at_end=False):
    os.environ["ZIPLINE_ROOT"] = str(out / "zipline")
    days = pd.DatetimeIndex(sorted(bars.ts_utc.dt.normalize().unique())).tz_localize(None)
    calendar = SyntheticWeekdays(start=days.min()-pd.Timedelta(days=30), end=days.max()+pd.Timedelta(days=10))
    calendars.register_calendar_type(calendar.name, SyntheticWeekdays, force=True)
    expected = calendar.sessions_in_range(days.min(),days.max())
    assert expected.equals(days), "calendar/input session keys differ"
    frames = {}
    for sid,(name,frame) in enumerate(bars.groupby("instrument_id",sort=True)):
        native = frame.set_index(frame.ts_utc.dt.normalize().dt.tz_localize(None))
        frames[sid] = native[["open","high","low","close","volume"]]
    names = sorted(bars.instrument_id.unique())
    def bundle(environ, asset_db_writer, minute_bar_writer, daily_bar_writer,
               adjustment_writer, calendar, start_session, end_session, cache, show_progress, output_dir):
        metadata = pd.DataFrame(dict(symbol=names, start_date=days.min(),end_date=days.max(),
            auto_close_date=days.max()+pd.Timedelta(days=0 if auto_close_at_end else 1),exchange="SYNTHETIC"),index=range(len(names)))
        exchanges = pd.DataFrame(dict(exchange=["SYNTHETIC"],canonical_name=["SYNTHETIC"],country_code=["US"]))
        asset_db_writer.write(equities=metadata,exchanges=exchanges)
        daily_bar_writer.write(iter(frames.items()),show_progress=False)
        adjustment_writer.write()
    register("ledgr_native",bundle,calendar_name=calendar.name,start_session=days.min(),end_session=days.max())
    ingest("ledgr_native",show_progress=False)
    from zipline.utils.calendar_utils import get_calendar
    return dict(names=names,days=days,calendar=get_calendar(calendar.name))

def run(prepared, trace=False):
    scores, intent = [], []
    def initialize(context):
        context.assets = [symbol(name) for name in prepared["names"]]
        context.previous = None
        context.count = 0
        set_commission(PerShare(cost=0,min_trade_cost=0))
        set_slippage(FixedSlippage(spread=0))
    def handle_data(context,data):
        context.count += 1
        n = min(context.count,10)
        history = data.history(context.assets,"close",n,"1d")
        fast = history.iloc[-5:].mean() if n>=5 else history.iloc[-1]*np.nan
        slow = history.mean() if n>=10 else fast*np.nan
        above = fast>slow if n>=10 else None
        stamp = get_datetime()
        if trace:
            scores.extend((stamp,asset.symbol,fast[asset],slow[asset]) for asset in context.assets)
        if above is not None and context.previous is not None:
            for asset in above.index[above != context.previous]:
                order_target(asset,int(above[asset]))
                if trace:
                    intent.append((stamp,asset.symbol,int(above[asset])))
        context.previous = above
    result = run_algorithm(start=prepared["days"].min(),end=prepared["days"].max(),
        initialize=initialize,handle_data=handle_data,capital_base=1e7,bundle="ledgr_native",
        data_frequency="daily",trading_calendar=prepared["calendar"],
        benchmark_returns=pd.Series(0.0,index=prepared["days"]),default_extension=False)
    fill_rows, position_rows = [], []
    for stamp,row in result.iterrows():
        for transaction in row.transactions:
            fill_rows.append((transaction["dt"],transaction["sid"].symbol,
                              transaction["amount"],transaction["price"],transaction.get("commission") or 0.0))
        position_rows.extend((stamp,position["sid"].symbol,position["amount"]) for position in row.positions)
    fills = pd.DataFrame(fill_rows,columns=["ts_utc","instrument_id","qty","price","fee"])
    holdings = pd.DataFrame(position_rows,columns=["ts_utc","instrument_id","qty"])
    equity = pd.DataFrame(dict(ts_utc=result.index,cash=result.ending_cash.values,equity=result.portfolio_value.values))
    return dict(fills=fills,equity=equity,holdings=holdings,
        scores=pd.DataFrame(scores,columns=["ts_utc","instrument_id","fast","slow"]) if trace else None,
        intent=pd.DataFrame(intent,columns=["ts_utc","instrument_id","target"]) if trace else None)

def terminal_probe(bars, out):
    """Native metadata sensitivity witness; no transaction or price is manufactured."""
    subset = bars[bars.instrument_id=="P11"].copy()
    rows, intents = [], []
    for policy, at_end in (("after_end",False),("at_end",True)):
        directory = out / policy
        directory.mkdir()
        native = run(prepare(subset,directory,auto_close_at_end=at_end),trace=True)
        end = pd.to_datetime(native["equity"].ts_utc,utc=True).max()
        holdings = native["holdings"]
        quantity = holdings.loc[pd.to_datetime(holdings.ts_utc,utc=True)==end,"qty"].sum()
        rows.append(dict(auto_close_policy=policy,fills=len(native["fills"]),terminal_quantity=quantity,
                         terminal_cash=native["equity"].cash.iloc[-1],terminal_equity=native["equity"].equity.iloc[-1]))
        intents.append(native["intent"])
        for name,frame in native.items():
            frame.to_csv(directory/(name+".csv"),index=False,float_format="%.17g")
    assert intents[0].equals(intents[1]), "metadata probe must keep the strategy's native intent unchanged"
    assert rows[0]["terminal_quantity"]>0 and rows[1]["terminal_quantity"]==0
    assert rows[1]["fills"]>rows[0]["fills"], "forced liquidation must appear as an actual native transaction"
    pd.DataFrame(rows).to_csv(out/"terminal_probe.csv",index=False,float_format="%.17g")
