"""bt 1.4.1 quantity transactions through its native Strategy API."""
import bt
import numpy as np
import pandas as pd

REUSE = "unchanged close matrix; new Algo, Strategy and Backtest each arm"

def prepare(bars, out):
    return bars.pivot(index="ts_utc", columns="instrument_id", values="close")

def run(prepared, trace=False):
    class Crossover(bt.Algo):
        def __init__(self):
            super().__init__()
            self.scores, self.intent = [], []
            self.above = None
        def __call__(self, target):
            history = target.universe.loc[:target.now].dropna(how="all")
            # Means are native strategy computations over known history, not target imports.
            fast = history.iloc[-5:].mean() if len(history)>=5 else history.iloc[-1]*np.nan
            slow = history.iloc[-10:].mean() if len(history)>=10 else fast*np.nan
            above = fast>slow if len(history)>=10 else None
            if trace:
                self.scores.extend((target.now, name, fast[name], slow[name]) for name in history.columns)
            if above is not None and self.above is not None:
                for name in above.index[above != self.above]:
                    child = target.children.get(name)
                    quantity = int(above[name])-(child.position if child is not None else 0)
                    if quantity:
                        target.transact(quantity, child=name)
                    if trace:
                        self.intent.append((target.now, name, int(above[name])))
            self.above = above
            return True
    algo = Crossover()
    strategy = bt.Strategy("transition", [algo], children=list(prepared.columns))
    backtest = bt.Backtest(strategy, prepared, initial_capital=1e7,
        commissions=lambda q,p:0, integer_positions=True, progress_bar=False)
    result = bt.run(backtest)
    native = backtest.strategy
    transactions = result.get_transactions().reset_index()
    fills = transactions.rename(columns={"Date":"ts_utc","Security":"instrument_id","quantity":"qty"})
    fills["fee"] = 0.0  # Native commission function is identically zero.
    equity = pd.DataFrame(dict(ts_utc=native.values.index, cash=native.cash.values, equity=native.values.values))
    equity = equity[equity.ts_utc.isin(prepared.index)]
    holdings = native.positions.reindex(index=prepared.index, columns=prepared.columns).fillna(0)
    holdings.index.name="ts_utc"
    # Backtest deep-copies the strategy/Algo; inspect the actually executed native copy.
    executed = native.stack.algos[0]
    return dict(fills=fills[["ts_utc","instrument_id","qty","price","fee"]], equity=equity,
        holdings=holdings.reset_index(),
        scores=pd.DataFrame(executed.scores, columns=["ts_utc","instrument_id","fast","slow"]) if trace else None,
        intent=pd.DataFrame(executed.intent, columns=["ts_utc","instrument_id","target"]) if trace else None)
