# Rerun native engines into scratch; compare actual economic/decision evidence.
file <- sub("^--file=","",grep("^--file=",commandArgs(FALSE),value=TRUE)[1L])
here <- dirname(normalizePath(file,winslash="/"))
source(file.path(here,"../dense/native.R"))
source(file.path(here,"records.R"),chdir=TRUE)
root <- normalizePath(file.path(here,"../../../.."),winslash="/")
before <- dense_scope(root)
records <- dense_arg("records")
id <- basename(normalizePath(records,mustWork=FALSE,winslash="/"))
if(!is.null(dense_arg("qualification")) || !is.null(dense_arg("append"))) {
  if(dir.exists(records)) stop("Collected record output must be new")
  record <- if(is.null(dense_arg("append"))) suite_collect(dense_arg("qualification"),id,dirname(here),dense_arg("inputs")) else
    readRDS(file.path(dense_arg("append"),"suite.rds"))
  record$id <- id
  record$assignments <- read.csv(suite_assignment_path)
  if(!is.null(dense_arg("measurement"))) record <- suite_measure(record,c(dense_arg("measurement"),dense_arg("measurement-extra")),
    readRDS(dense_arg("controls")),dense_arg("inputs"),lane=dense_arg("lane","headline"))
  if(!is.null(dense_arg("previous"))) {
    record$previous_attempts <- jsonlite::fromJSON(file.path(dense_arg("previous"),"attempts.json"))
    record$previous_unrun <- 5L*sum(record$assignments$lane=="headline")-nrow(record$previous_attempts)
  }
  if(!is.null(dense_arg("withdrawn"))) {
    withdrawn <- dense_arg("withdrawn")
    record$withdrawn <- list(attempts=jsonlite::fromJSON(file.path(withdrawn,"attempts.json")),
      session=jsonlite::fromJSON(file.path(withdrawn,"session.json")),
      clocks=read.csv(file.path(withdrawn,"captured_clocks.csv")),
      note=jsonlite::fromJSON(file.path(withdrawn,"executor_stop_note.json")))
  }
  dir.create(records,recursive=TRUE)
  saveRDS(record,file.path(records,"suite.rds"),version=3L)
  for(name in c("comparisons","coverage","timings","memory","financial")) if(!is.null(record[[name]]))
    write.csv(record[[name]],file.path(records,paste0(name,".csv")),row.names=FALSE)
} else record <- readRDS(file.path(records,"suite.rds"))
suite_validate(record,id)
if(!is.null(dense_arg("qualify-matrix"))) {
  raw <- dense_arg("qualify-matrix")
  shapes <- unique(jsonlite::fromJSON(file.path(raw,"attempts.json"))$shape)
  controls <- lapply(shapes,function(shape) suite_collect(raw,id,dirname(here),dense_arg("inputs"),shape,
    reference=if(grepl("_N",shape)) record else NULL))
  comparisons <- do.call(rbind,lapply(controls,attr,"comparisons"))
  controls <- do.call(rbind,controls)
  attr(controls,"comparisons") <- comparisons
  stopifnot(!file.exists(dense_arg("controls")))
  saveRDS(controls,dense_arg("controls"),version=3L)
}
scratch <- dense_arg("scratch")
if(!is.null(scratch)) {
  powershell <- "C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe"
  code <- system2(powershell,c("-NoProfile","-File",shQuote(file.path(here,"run_suite.ps1")),
    "-Mode qualify","-Out",shQuote(scratch),"-Inputs",shQuote(dense_arg("inputs")),
    if(identical(dense_arg("session-scratch"),"true")) "-Lane sessions -QualifyShape 12x90_N10"))
  stopifnot(code==0L)
  fields <- c("fills","equity","holdings","scores","intent","state")
  engines <- if(identical(dense_arg("session-scratch"),"true")) c("ledgr","pmwr","pybroker","vectorbt") else names(record$native)
  diffs <- lapply(engines,function(engine) {
    actual <- suite_read(file.path(scratch,paste0(if(identical(dense_arg("session-scratch"),"true")) "12x90_N10_" else "12x90_",engine,"_01")),engine=engine)
    selected <- intersect(fields,names(record$native[[engine]]))
    dense_diff(record$native[[engine]][selected],actual[selected],engine)
  })
  for(flow in names(record$workflows)) {
    x <- suite_read(file.path(scratch,paste0(if(identical(dense_arg("session-scratch"),"true")) "12x90_N10_ledgr_" else "12x90_ledgr_",flow,"_01")))
    diffs[[length(diffs)+1L]] <- dense_diff(record$workflows[[flow]][c("equity","closed_trades")],x[c("equity","closed_trades")],flow)
  }
  diff <- do.call(rbind,diffs)
  write.csv(diff,file.path(scratch,"diff.csv"),row.names=FALSE)
  stopifnot(nrow(diff)==0L)
  if(identical(dense_arg("session-scratch"),"true")) {
    controls <- suite_collect(scratch,id,dirname(here),dense_arg("inputs"),"12x90_N10",reference=record)
    stopifnot(nrow(controls)==6L)
    attempts <- jsonlite::fromJSON(file.path(scratch,"attempts.json"))
    bad <- attempts[1L,]
    bad$completed_warm <- bad$completed_warm-1L
    stopifnot(inherits(try(suite_books(bad),silent=TRUE),"try-error"))
    partial <- attempts[1L,]
    partial$status <- "censored"
    partial$completed_warm <- 0L
    books <- suite_books(attempts[1L,])
    books$warm <- books$warm[FALSE,]
    suite_books(partial,books)
  }
  cat("PASS: exact native scratch diff, selected peers and requested session books.\n")
}
if(identical(dense_arg("gut"),"true")) {
  fails <- function(code) inherits(try(force(code),silent=TRUE),"try-error")
  bad <- record$native$ledgr
  bad$fills$qty[1L] <- bad$fills$qty[1L]+1
  stopifnot(nrow(dense_diff(record$native$ledgr,bad))>0L,
    identical(record$native$ledgr$equity,bad$equity))
  altered <- record
  altered$native$ledgr <- bad
  stopifnot(fails(suite_validate(altered,altered$id)))
  bad <- record
  bad$timings$clock_sec[1L] <- 0
  stopifnot(fails(suite_validate(bad,bad$id)))
  bad <- record
  i <- which(bad$comparisons$engine=="pmwr")
  bad$comparisons$ratio_eligible[i] <- TRUE
  bad$comparisons$agreement[i] <- "same trades and balances"
  stopifnot(fails(suite_validate(bad,bad$id)),fails(suite_validate(record,"wrong-record")))
  bad <- record
  bad$attempts <- if(is.null(record$attempts)) NULL else subset(record$attempts,repetition<=2L)
  bad$timings <- record$timings[record$timings$id %in% bad$attempts$id,,drop=FALSE]
  bad$lifecycle <- record$lifecycle[intersect(names(record$lifecycle),bad$attempts$id)]
  bad$books <- record$books[intersect(names(record$books),bad$attempts$id)]
  bad$comparisons$ratio_eligible <- FALSE
  suite_validate(bad,bad$id)
  bad$comparisons$ratio_eligible[tail(which(bad$comparisons$engine=="quantstrat"),1L)] <- TRUE
  stopifnot(fails(suite_validate(bad,bad$id)))
  bad <- record
  bad$coverage <- bad$coverage[bad$coverage$engine!="pmwr",]
  stopifnot(fails(suite_validate(bad,bad$id)))
  guts <- dense_arg("gut-dir")
  stopifnot(!is.null(guts),!dir.exists(guts))
  dir.create(guts,recursive=TRUE)
  for(kind in c("reuse","completed")) {
    out <- file.path(guts,kind)
    status <- system2("C:/Program Files/R/R-4.6.1/bin/x64/Rscript.exe",c("--vanilla",shQuote(file.path(here,"run.R")),
      "--engine=ledgr",paste0("--gut=",kind),paste0("--out=",shQuote(out)),
      paste0("--input=",shQuote(file.path(dense_arg("inputs"),"12x90.csv"))),
      "--library=C:/Users/maxth/AppData/Local/Temp/ledgr-ws3-library-891c23c8",
      if(identical(dense_arg("session-scratch"),"true")) "--iterations=10"),
      stdout=file.path(guts,paste0(kind,".stdout")),stderr=file.path(guts,paste0(kind,".stderr")))
    if(kind=="reuse") stopifnot(status==0L,!identical(suite_read(out)$equity,suite_read(out,"warm")$equity)) else
      stopifnot(status!=0L,any(grepl("Completed-run reuse detected",readLines(file.path(guts,paste0(kind,".stderr"))))))
  }
  for(kind in c("retention","retention-gut")) {
    status <- system2(dense_arg("python","C:/Users/maxth/.cache/ledgr-peer-benchmark/native-python-ws5-20261031/Scripts/python.exe"),
      c(shQuote(file.path(here,"python/record_io.py")),"--engine=backtrader",paste0("--probe=",kind),
        paste0("--input=",shQuote(file.path(dense_arg("inputs"),"12x90.csv"))),
        paste0("--out=",shQuote(file.path(guts,kind))),paste0("--launch=",format(as.numeric(Sys.time()),scientific=FALSE,digits=16))),
      stdout=file.path(guts,paste0(kind,".stdout")),stderr=file.path(guts,paste0(kind,".stderr")))
    observed <- jsonlite::fromJSON(file.path(guts,kind,"retention_probe.json"))
    stopifnot(status==if(kind=="retention") 0L else 1L,identical(observed$cold_capture_retained,kind=="retention-gut"))
  }
  cat("PASS: changed fill with unchanged equity; false equivalence; wrong record; omitted peer; insufficient-repeat ratio; actual cash/DONE reuse and Python cold-capture lifetime detected.\n")
}

stopifnot(identical(before,dense_scope(root)))
