param([ValidateSet('functions','witness','child','hostwitness','lifetimewitness')][string]$SamplerMode='functions', [string]$WitnessOut,
  [string]$PeerLibrary='C:/Users/maxth/AppData/Local/Temp/ledgr-peer-suite-cut3-r-library-isolated')
$ErrorActionPreference = 'Stop'
function Get-ObservedPhase([string]$Path) {
  if (-not (Test-Path -LiteralPath $Path)) { return 'startup' }
  $value=Get-Content -LiteralPath $Path -Raw
  if ([string]::IsNullOrWhiteSpace($value)) { return 'transition_unobserved' }
  ([string]$value).Trim()
}
function Get-TreeMemory([int]$RootId, [string]$Phase, $ExpectedRootCreated=$null) {
  $script:MemorySampleGap=$false
  $processRows = @(Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcessId,Name,CreationDate)
  $script:MemoryProcessRows=$processRows
  $byId=@{}
  foreach ($row in $processRows) { $byId[[int]$row.ProcessId]=$row }
  $rootRow=$byId[$RootId]
  if ($null -ne $ExpectedRootCreated -and $null -ne $rootRow.CreationDate -and
      ([DateTimeOffset]$rootRow.CreationDate).ToUnixTimeMilliseconds() -ne ([DateTimeOffset]$ExpectedRootCreated).ToUnixTimeMilliseconds()) {
    $script:MemorySampleGap=$true
    return
  }
  $ids = New-Object 'System.Collections.Generic.HashSet[int]'
  [void]$ids.Add($RootId)
  do {
    $count = $ids.Count
    foreach ($row in $processRows) {
      $parent=$byId[[int]$row.ParentProcessId]
      if ($ids.Contains([int]$row.ParentProcessId) -and $null -ne $parent) {
        if ($null -eq $row.CreationDate -or $null -eq $parent.CreationDate) { $script:MemorySampleGap=$true; continue }
        if ($row.CreationDate -ge $parent.CreationDate) { [void]$ids.Add([int]$row.ProcessId) }
      }
    }
  } while ($ids.Count -ne $count)
  $stamp = [DateTime]::UtcNow.ToString('o')
  foreach ($processId in $ids) {
    if ($null -eq $byId[$processId].CreationDate) { $script:MemorySampleGap=$true; continue }
    $p = Get-Process -Id $processId -ErrorAction SilentlyContinue
    if ($null -ne $p) {
      try {
        $affinity=$p.ProcessorAffinity.ToInt64()
        if (([DateTimeOffset]$p.StartTime).ToUnixTimeMilliseconds() -ne ([DateTimeOffset]$byId[$processId].CreationDate).ToUnixTimeMilliseconds()) {
          $script:MemorySampleGap=$true
          continue
        }
      } catch { $script:MemorySampleGap=$true; continue }
      [pscustomobject]@{ utc=$stamp; phase=$Phase; root_pid=$RootId; pid=$processId;
        name=$byId[$processId].Name; parent_pid=$byId[$processId].ParentProcessId;
        created_utc=$byId[$processId].CreationDate.ToUniversalTime().ToString("o");
        working_set=[double]$p.WorkingSet64; private_bytes=[double]$p.PrivateMemorySize64;
        affinity=$affinity; cpu_sec=[double]$p.CPU }
    }
  }
}
function Get-HostViolation($Samples,[int]$RootId) {
  $ids=@($Samples | Select-Object -ExpandProperty pid)
  $foreign=@($script:MemoryProcessRows | Where-Object {
    $_.Name -in @('R.exe','Rscript.exe','Rterm.exe','Rgui.exe','rsession.exe') -and
    $_.ProcessId -notin $ids -and $_.ProcessId -ne $RootId
  })
  $script:ForeignRSeen=$foreign
  $affinity=@($Samples | Where-Object affinity -ne 65535)
  if ($affinity.Count -gt 0) {
    [pscustomobject]@{ other_R=$foreign; affinity=$affinity }
  }
}
function Get-MemoryPhases($Samples) {
  $trees = @($Samples | Group-Object utc | ForEach-Object {
    [pscustomobject]@{ utc=$_.Name; phase=$_.Group[0].phase;
      working_set=($_.Group | Measure-Object working_set -Sum).Sum;
      private_bytes=($_.Group | Measure-Object private_bytes -Sum).Sum;
      processes=$_.Count }
  })
  @($trees | Group-Object phase | ForEach-Object {
    [pscustomobject]@{ phase=$_.Name; samples=$_.Count;
      peak_working_set=($_.Group | Measure-Object working_set -Maximum).Maximum;
      peak_private_bytes=($_.Group | Measure-Object private_bytes -Maximum).Maximum;
      max_processes=($_.Group | Measure-Object processes -Maximum).Maximum }
  })
}
if ($SamplerMode -eq 'child') {
  [Diagnostics.Process]::GetCurrentProcess().ProcessorAffinity=[IntPtr]0xFFFFFF
  $buffer = New-Object byte[] (128MB)
  for ($i=0; $i -lt $buffer.Length; $i+=4096) { $buffer[$i]=1 }
  [IO.File]::WriteAllText((Join-Path $WitnessOut 'allocated.txt'),[string]$PID)
  Start-Sleep -Seconds 4
  [GC]::KeepAlive($buffer)
}
if ($SamplerMode -eq 'witness') {
  [Diagnostics.Process]::GetCurrentProcess().ProcessorAffinity=[IntPtr]0xFFFF
  $affinityDetected=$false
  [void](New-Item -ItemType Directory -Path $WitnessOut)
  $start = New-Object Diagnostics.ProcessStartInfo
  $start.FileName = 'C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe'
  $start.Arguments = '-NoProfile -File "{0}" -SamplerMode child -WitnessOut "{1}"' -f $PSCommandPath,$WitnessOut
  $start.UseShellExecute=$false
  $start.CreateNoWindow=$true
  $child = [Diagnostics.Process]::Start($start)
  $samples = New-Object 'System.Collections.Generic.List[object]'
  while (-not $child.HasExited) {
    $tree=@(Get-TreeMemory $PID 'witness')
    foreach ($sample in $tree) { $samples.Add($sample) }
    $violation=Get-HostViolation $tree $PID
    if ($null -ne $violation -and $child.Id -in @($violation.affinity.pid)) { $affinityDetected=$true }
    Start-Sleep -Milliseconds 250
  }
  $all = @(Get-MemoryPhases $samples.ToArray())
  $gutted = @(Get-MemoryPhases @($samples | Where-Object pid -ne $child.Id))
  $detected = $all[0].peak_private_bytes-$gutted[0].peak_private_bytes -gt 100MB
  if (-not $detected -or -not $affinityDetected -or $all[0].max_processes -lt 2) { throw 'Allocating descendant attribution witness failed' }
  $samples.ToArray() | Export-Csv -NoTypeInformation -Path (Join-Path $WitnessOut 'samples.csv')
  [pscustomobject]@{ child_pid=$child.Id; allocated_bytes=128MB;
    peak_with_child=$all[0].peak_private_bytes; peak_without_child=$gutted[0].peak_private_bytes;
    omitted_child_detected=$detected; affinity_violation_detected=$affinityDetected; interval_ms=250 } |
    Export-Csv -NoTypeInformation -Path (Join-Path $WitnessOut 'gut.csv')
  Write-Host 'PASS: real 128MiB descendant omitted by gut; attribution difference detected.'
}

if ($SamplerMode -eq 'hostwitness') {
  [Diagnostics.Process]::GetCurrentProcess().ProcessorAffinity=[IntPtr]0xFFFF
  [void](New-Item -ItemType Directory -Path $WitnessOut)
  $checks=New-Object 'System.Collections.Generic.List[object]'
  function Start-ForeignR {
    $info=New-Object Diagnostics.ProcessStartInfo
    $info.FileName='C:/Program Files/R/R-4.6.1/bin/x64/Rscript.exe'
    $info.Arguments='--vanilla -e "Sys.sleep(30)"'
    $info.UseShellExecute=$false
    $info.CreateNoWindow=$true
    [Diagnostics.Process]::Start($info)
  }
  foreach ($boundary in @('preflight','postflight')) {
    $foreign=$null
    $controller=$null
    $directory=Join-Path $WitnessOut $boundary
    try {
      if ($boundary -eq 'preflight') {
        $foreign=Start-ForeignR
        Start-Sleep -Milliseconds 500
      }
      $info=New-Object Diagnostics.ProcessStartInfo
      $info.FileName='C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe'
      $info.Arguments='-NoProfile -File "{0}" -Mode measure -OnlyEngines pmwr -Out "{1}" -Library "{2}"' -f
        (Join-Path $PSScriptRoot 'run_suite.ps1'),$directory,$PeerLibrary
      $info.UseShellExecute=$false
      $info.CreateNoWindow=$true
      $info.RedirectStandardOutput=$true
      $info.RedirectStandardError=$true
      $controller=[Diagnostics.Process]::Start($info)
      $stdout=$controller.StandardOutput.ReadToEndAsync()
      $stderr=$controller.StandardError.ReadToEndAsync()
      if ($boundary -eq 'postflight') {
        $phase=Join-Path $directory '500x1260_pmwr_01/phase.txt'
        $watch=[Diagnostics.Stopwatch]::StartNew()
        do {
          if ($controller.HasExited -or $watch.Elapsed.TotalSeconds -gt 60) { throw 'Postflight witness did not reach worker completion' }
          Start-Sleep -Milliseconds 10
        } while (-not (Test-Path -LiteralPath $phase) -or (Get-ObservedPhase $phase) -ne 'complete')
        do {
          $tree=@(Get-TreeMemory $controller.Id 'hostwitness')
          $native=@($tree | Where-Object name -in @('R.exe','Rscript.exe','Rterm.exe'))
          if ($watch.Elapsed.TotalSeconds -gt 60) { throw 'Postflight worker did not exit' }
        } while ($native.Count -gt 0)
        $foreign=Start-ForeignR
      }
      if (-not $controller.WaitForExit(120000)) { throw "Host witness controller did not finish" }
      [IO.File]::WriteAllText((Join-Path $WitnessOut ($boundary+'.stdout.txt')),$stdout.GetAwaiter().GetResult())
      [IO.File]::WriteAllText((Join-Path $WitnessOut ($boundary+'.stderr.txt')),$stderr.GetAwaiter().GetResult())
      $attempts=Get-Content -LiteralPath (Join-Path $directory 'attempts.json') -Raw | ConvertFrom-Json
      $session=Get-Content -LiteralPath (Join-Path $directory 'session.json') -Raw | ConvertFrom-Json
      $completed=@($attempts | Where-Object status -eq 'complete').Count
      $observed=if ($boundary -eq 'preflight') { @($attempts[0].other_R_before.ProcessId) } else { @($attempts[0].other_R_after.ProcessId) }
      if ($controller.ExitCode -ne 0 -or $attempts.Count -ne 5 -or $completed -ne 5 -or
          $foreign.Id -notin $observed -or $session.stopped) { throw ('Idle-R annotation witness failed at '+$boundary) }
      $checks.Add([pscustomobject]@{ boundary=$boundary; slots=$attempts.Count; completed=$completed;
        status='complete'; idle_R_recorded=$true; controller_exit=$controller.ExitCode })
    } finally {
      foreach ($owned in @($foreign,$controller)) {
        if ($null -ne $owned -and -not $owned.HasExited) { $owned.WaitForExit() }
      }
    }
  }
  $checks.ToArray() | Export-Csv -NoTypeInformation -Path (Join-Path $WitnessOut 'host_gut.csv')
  Write-Host 'PASS: real idle R at preflight and postflight is recorded; all native pairs complete; no process terminated.'
}


# CIM may lose creation-time fields while a process is starting/exiting.
# Unknown/reused identities are omitted and explicitly reported, never zeroed.
if ($SamplerMode -eq 'lifetimewitness') {
  [void](New-Item -ItemType Directory -Path $WitnessOut)
  $script:lifetimeRows=@(Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcessId,Name,CreationDate)
  function Get-CimInstance { $script:lifetimeRows }
  $normal=@(Get-TreeMemory $PID 'control')
  $normalGap=$script:MemorySampleGap
  $own=$script:lifetimeRows | Where-Object ProcessId -eq $PID
  $born=$own.CreationDate
  $own.CreationDate=$null
  $missing=@(Get-TreeMemory $PID 'missing_birth' $born)
  $missingGap=$script:MemorySampleGap
  $own.CreationDate=$born
  $recovered=@(Get-TreeMemory $PID 'recovered' $born)
  $recoveredGap=$script:MemorySampleGap
  $reused=@(Get-TreeMemory $PID 'different_root' $born.AddSeconds(-1))
  $reuseGap=$script:MemorySampleGap
  if ($normal.Count -lt 1 -or $normalGap -or $missing.Count -ne 0 -or -not $missingGap -or
      $recovered.Count -lt 1 -or $recoveredGap -or $reused.Count -ne 0 -or -not $reuseGap) { throw 'Sampler lifetime control/gut failed' }
  [pscustomobject]@{ control_rows=$normal.Count; missing_birth_rows=$missing.Count; missing_identity_reported=$missingGap;
    recovered_rows=$recovered.Count; reused_root_rows=$reused.Count; root_mismatch_reported=$reuseGap } |
    Export-Csv -NoTypeInformation -Path (Join-Path $WitnessOut 'lifetime_gut.csv')
  $phasePath=Join-Path $WitnessOut 'phase.txt'
  $beforePhase=Get-ObservedPhase $phasePath
  [IO.File]::WriteAllText($phasePath,'')
  $emptyPhase=Get-ObservedPhase $phasePath
  [IO.File]::WriteAllText($phasePath,"warm`n")
  $afterPhase=Get-ObservedPhase $phasePath
  if ($beforePhase -ne 'startup' -or $emptyPhase -ne 'transition_unobserved' -or $afterPhase -ne 'warm') { throw 'Phase transition observation failed' }
  [pscustomobject]@{ before=$beforePhase; empty=$emptyPhase; recovered=$afterPhase } |
    Export-Csv -NoTypeInformation -Path (Join-Path $WitnessOut 'phase_gut.csv')
  Write-Host 'PASS: missing/reused identities emit no invented rows, gaps are explicit, valid sampling recovers.'
}
