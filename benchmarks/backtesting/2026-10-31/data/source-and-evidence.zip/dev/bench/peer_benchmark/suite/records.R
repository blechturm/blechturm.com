# Keyed native evidence only: no fill, funding or accounting simulator.
suite_assignment_path <- normalizePath("assignments.csv",winslash="/")
suite_stamp <- function(x) {
  keys <- as.character(x)
  unique_keys <- unique(keys)
  values <- sub("T"," ",sub("(Z|\\+00:00)$","",unique_keys))
  stamps <- format(as.POSIXct(values,tz="UTC"),"%Y-%m-%dT%H:%M:%SZ",tz="UTC")
  stamps[match(keys,unique_keys)]
}
suite_read <- function(path,arm="cold",engine="ledgr") {
  if(engine %in% c("ledgr","pmwr","quantstrat")) {
    out <- readRDS(file.path(path,paste0(arm,"_native.rds")))
  } else {
    files <- list.files(path,pattern=paste0("^",arm,"_.*[.]csv$"),full.names=TRUE)
    out <- lapply(files,read.csv,check.names=FALSE,na.strings=c("NA","NaN",""))
    names(out) <- sub(paste0("^",arm,"_"),"",sub("[.]csv$","",basename(files)))
  }
  for(name in names(out)) if(!is.null(out[[name]])) {
    x <- out[[name]]
    if("ts_utc" %in% names(x)) x$ts_utc <- suite_stamp(x$ts_utc)
    if(name=="fills") x <- x[order(x$ts_utc,seq_len(nrow(x))),,drop=FALSE]
    rownames(x) <- NULL
    out[[name]] <- x
  }
  out
}
suite_scores <- function(native) {
  if(!is.null(native$scores)) return(native$scores)
  con <- textConnection(paste(native$state$state_json,collapse="\n"))
  on.exit(close(con),add=TRUE)
  state <- jsonlite::stream_in(con,verbose=FALSE)
  ids <- names(state$above)
  data.frame(ts_utc=rep(native$state$ts_utc,length(ids)),instrument_id=rep(ids,each=nrow(state)),
    fast=as.numeric(as.matrix(state$fast)),slow=as.numeric(as.matrix(state$slow)),
    target=as.numeric(as.matrix(state$targets)))
}
suite_positions <- function(native,bars,sparse=FALSE) {
  x <- native$holdings
  if(!"instrument_id" %in% names(x)) {
    ids <- setdiff(names(x),"ts_utc")
    x <- data.frame(ts_utc=rep(x$ts_utc,length(ids)),instrument_id=rep(ids,each=nrow(x)),
      qty=as.numeric(as.matrix(x[ids])))
  } else if("Pos.Qty" %in% names(x)) x$qty <- x$Pos.Qty
  key <- paste(x$ts_utc,x$instrument_id)
  i <- match(paste(suite_stamp(bars$ts_utc),bars$instrument_id),key)
  stopifnot(!anyDuplicated(key),sparse || !anyNA(i))
  value <- as.numeric(x$qty[i])
  if(sparse) value[is.na(i)] <- 0
  stopifnot(all(is.finite(value)))
  value
}
suite_compare <- function(expected,actual,bars,engine="") {
  a <- suite_scores(expected)
  b <- suite_scores(actual)
  keys <- function(x) paste(x$ts_utc,x$instrument_id)
  align <- function(x,y) {
    stopifnot(!anyDuplicated(keys(x)),!anyDuplicated(keys(y)),setequal(keys(x),keys(y)))
    y[match(keys(x),keys(y)),,drop=FALSE]
  }
  b <- align(a,b)
  u <- 2^-53
  gamma <- function(k) k*u/(1-k*u)
  bound <- gamma(8*length(unique(bars$ts_utc))+64)*max(1,abs(bars$close))
  mask <- identical(unname(is.na(as.matrix(a[c("fast","slow")]))),unname(is.na(as.matrix(b[c("fast","slow")]))))
  delta <- max(abs(as.matrix(a[c("fast","slow")])-as.matrix(b[c("fast","slow")])),na.rm=TRUE)
  numeric <- mask && all(abs(as.matrix(a[c("fast","slow")])-as.matrix(b[c("fast","slow")])) <= bound+8*u*pmax(abs(as.matrix(a[c("fast","slow")])),abs(as.matrix(b[c("fast","slow")]))),na.rm=TRUE)
  stopifnot(!any(is.infinite(as.matrix(a[c("fast","slow")]))),!any(is.infinite(as.matrix(b[c("fast","slow")]))))
  observed <- actual$intent
  if(is.null(observed) && all(c("enter","exit") %in% names(b))) {
    observed <- b[b$enter==1 | b$exit==1,c("ts_utc","instrument_id","enter")]
    names(observed)[3L] <- "target"
  }
  stopifnot(!is.null(observed))
  times <- sort(unique(a$ts_utc))
  ids <- sort(unique(a$instrument_id),method="radix")
  # Expand native desired quantities only; this does not create fills or account balances.
  events <- rbind(data.frame(ts_utc=times[1L],instrument_id=ids,target=0),observed)
  key <- function(x) match(x$instrument_id,ids)*(length(times)+1L)+match(x$ts_utc,times)
  events <- events[order(key(events)),]
  target <- as.numeric(events$target[findInterval(key(a),key(events))])
  intent_ok <- identical(as.numeric(a$target[a$ts_utc<tail(times,1L)]),target[a$ts_utc<tail(times,1L)])
  above <- function(x) is.finite(x$fast) & is.finite(x$slow) & x$fast>x$slow
  discrete <- mask && identical(above(a),above(b))
  fa <- expected$fills
  fb <- actual$fills
  fill_keys <- identical(keys(fa),keys(fb))
  if(setequal(keys(fa),keys(fb)) && !anyDuplicated(keys(fb))) fb <- fb[match(keys(fa),keys(fb)),,drop=FALSE]
  quantity <- identical(keys(fa),keys(fb)) && identical(as.numeric(fa$qty),as.numeric(fb$qty))
  price <- if(quantity) max(abs(fa$price-fb$price)) else NA_real_
  price_ok <- quantity && all(abs(fa$price-fb$price)<=8*u+8*u*pmax(abs(fa$price),abs(fb$price)))
  positions <- identical(suite_positions(expected,bars),suite_positions(actual,bars,engine=="zipline"))
  ea <- expected$equity
  eb <- actual$equity[match(ea$ts_utc,actual$equity$ts_utc),,drop=FALSE]
  stopifnot(!anyDuplicated(actual$equity$ts_utc),!anyNA(eb$ts_utc))
  H <- max(rowsum(as.numeric(suite_positions(expected,bars)>0),bars$ts_utc))
  k <- 8*nrow(fa)+8*H+64
  magnitude <- 1e7+sum(abs(fa$qty*fa$price))+sum(abs(fa$fee))+max(abs(ea$equity-ea$cash))
  balance_bound <- gamma(k)*magnitude
  balance_difference <- max(abs(as.matrix(ea[c("cash","equity")])-as.matrix(eb[c("cash","equity")])))
  balances <- all(abs(as.matrix(ea[c("cash","equity")])-as.matrix(eb[c("cash","equity")])) <= balance_bound+8*u*pmax(abs(as.matrix(ea[c("cash","equity")])),abs(as.matrix(eb[c("cash","equity")]))))
  full <- numeric && discrete && intent_ok && fill_keys && price_ok && positions && balances && all(fa$fee==0) && all(fb$fee==0)
  data.frame(intent_agreement=intent_ok,score_mask=mask,score_bound=bound,max_score_difference=delta,score_agreement=numeric,
    discrete_above_agreement=discrete,fill_order_agreement=fill_keys,quantity_agreement=quantity,
    max_price_difference=price,price_agreement=price_ok,holdings_agreement=positions,
    balance_bound=balance_bound,max_balance_difference=balance_difference,balance_agreement=balances,
    agreement=if(full) "same trades and balances" else if(!numeric || !discrete || !intent_ok) "classified residual" else "same decisions only",
    reason=if(full) "Scores, native fill order/quantities/prices/fees, full holdings and balances qualify" else if(!numeric) "Native score precision exceeds the fixed bound" else if(!intent_ok) "Native target-intent timelines differ" else if(!quantity) "Native execution sessions differ" else if(!price_ok) "Native reported execution prices differ" else if(!fill_keys) "Native within-pulse fill order differs" else "Native holdings or balances differ")
}
suite_coverage <- function(assignments,comparisons,executed) {
  do.call(rbind,lapply(names(executed),function(engine) {
    x <- comparisons[comparisons$engine==engine,]
    required <- sum(assignments$engine==engine)
    data.frame(engine=engine,required=required,executed=executed[[engine]],
      trade_balance_agreement=sum(x$agreement=="same trades and balances"),
      decision_only_agreement=sum(x$agreement=="same decisions only"),
      classified_residual=sum(x$agreement=="classified residual"),not_run=required-executed[[engine]])
  }))
}
suite_validate <- function(record,id) {
  stopifnot(identical(record$id,id),!is.null(record$assignments),!anyDuplicated(record$assignments$key),
    setequal(record$assignments$key,read.csv(suite_assignment_path)$key))
  peers <- record$assignments$engine[record$assignments$lane=="dense_native"]
  stopifnot(setequal(record$assignments$engine[record$assignments$lane=="dense_native"],peers))
  stopifnot(setequal(record$coverage$engine,peers),all(record$coverage$required==
    as.integer(table(record$assignments$engine)[record$coverage$engine])))
  if(!is.null(record$native)) {
    stopifnot(setequal(names(record$native),peers))
    observed <- vapply(names(record$native),function(engine) suite_control(record$native[[engine]],record$bars,engine),"")
    stopifnot(identical(observed,record$qualification_controls),setequal(names(record$workflows),c("ephemeral","spot_fifo")))
  }
  if(nrow(record$timings)) stopifnot(all(record$timings$clock_sec>0),all(is.finite(record$timings$clock_sec)))
  if(!is.null(record$attempts)) {
    a <- record$attempts
    stopifnot(!anyDuplicated(a$id),all(a$mode=="measure"),all(a$harness_revision!=""))
    complete <- a$status=="complete"
    stopifnot(setequal(names(record$lifecycle),a$id[complete & a$engine=="ledgr"]),!anyDuplicated(record$controls$key))
    for(id in names(record$lifecycle)) {
      row <- a[a$id==id,]
      suffix <- if(grepl("_N",row$shape)) paste0("_",sprintf("%04d",row$requested)) else ""
      stopifnot(identical(c(record$lifecycle[[id]]$cold$run_id,record$lifecycle[[id]]$warm$run_id),paste0(c("suite_cold","suite_warm"),suffix)))
    }
    session <- a[grepl("_N",a$shape),]
    stopifnot(setequal(names(record$books),session$id))
    for(i in seq_len(nrow(session))) suite_books(session[i,],record$books[[session$id[i]]])
    stopifnot(all(a$affinity[complete]==65535),all(grepl("8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c",a$power_plan[complete])))
    pairs <- tapply(record$timings$arm,record$timings$id,function(x) identical(x,c("cold","warm")))
    stopifnot(setequal(names(pairs),a$id[complete]),all(pairs))
    controls <- record$controls$control[match(record$timings$key,record$controls$key)]
    stopifnot(!anyNA(controls),identical(controls,record$timings$native_control),
      all(record$timings$outputs==ifelse(record$timings$workflow=="durable","fills;equity;cash;asset_holdings","equity;closed_trade_pnl")))
  }
  if(!is.null(record$withdrawn)) stopifnot(identical(record$withdrawn$note$performance_admissible,FALSE),
    all(toupper(record$withdrawn$clocks$performance_admissible)=="FALSE"),
    !any(record$withdrawn$attempts$directory %in% record$attempts$directory))
  if(nrow(record$comparisons)) {
    flags <- c("intent_agreement","score_agreement","discrete_above_agreement","fill_order_agreement",
      "quantity_agreement","price_agreement","holdings_agreement","balance_agreement")
    eligible <- record$comparisons$ratio_eligible
    paired <- function(peer,shape) sum(a$engine==peer & a$shape==shape & a$workflow=="durable" & a$status=="complete")==5L
    stopifnot(!any(eligible & (record$comparisons$agreement!="same trades and balances" | record$comparisons$shape=="1166x7200")),
      !any(eligible) || (!is.null(record$attempts) && all(as.matrix(record$comparisons[eligible,flags])) &&
        all(vapply(which(eligible),function(i) paired(record$comparisons$engine[i],record$comparisons$shape[i]) &&
          paired("ledgr",record$comparisons$shape[i]),logical(1L)))))
  }
  invisible(TRUE)
}

suite_rows <- function(x,y) {
  if(is.null(x) || !nrow(x)) return(y)
  if(is.null(y) || !nrow(y)) return(x)
  x[setdiff(names(y),names(x))] <- NA
  y[setdiff(names(x),names(y))] <- NA
  rbind(x,y[names(x)])
}
suite_books <- function(a,books=NULL) {
  requested <- if(grepl("_N",a$shape)) as.integer(sub("^.*_N","",a$shape)) else 1L
  if(requested==1L) return(NULL)
  stopifnot(a$requested==requested)
  if(is.null(books)) books <- stats::setNames(lapply(c("cold","warm"),function(arm) {
    path <- file.path(a$directory,paste0(arm,"_books.csv"))
    if(file.exists(path)) read.csv(path) else data.frame(iteration=integer(),run_id=character(),financial_identical=logical())
  }),c("cold","warm"))
  for(arm in names(books)) {
    b <- books[[arm]]
    expected_ids <- if(nrow(b)) paste0("suite_",arm,"_",sprintf("%04d",seq_len(nrow(b)))) else character()
    stopifnot(nrow(b)==a[[paste0("completed_",arm)]],nrow(b)<=requested,
      identical(as.integer(b$iteration),seq_len(nrow(b))),
      identical(as.character(b$run_id),expected_ids))
    if(a$engine=="ledgr" && a$workflow!="durable" && nrow(b))
      stopifnot("engine_sec" %in% names(b),all(is.finite(b$engine_sec)),all(b$engine_sec>0))
    if(a$status=="complete") stopifnot(nrow(b)==requested,isTRUE(all(toupper(as.character(b$financial_identical))=="TRUE")))
  }
  stopifnot(identical(names(books),c("cold","warm")))
  books
}
suite_collect <- function(raw,id,base,inputs,shape="12x90",reference=NULL) {
  all_attempts <- jsonlite::fromJSON(file.path(raw,"attempts.json"))
  all_attempts <- all_attempts[all_attempts$shape==shape,]
  assignments <- read.csv(file.path(base,"suite/assignments.csv"))
  required <- assignments[assignments$shape==shape,]
  stopifnot(nrow(all_attempts)==nrow(required),!anyDuplicated(all_attempts$id),all(all_attempts$mode=="qualify"),
    setequal(paste(all_attempts$engine,all_attempts$workflow),paste(required$engine,required$workflow)))
  bars <- read.csv(file.path(inputs,paste0(sub("_N[0-9]+$","",shape),".csv")))
  attempts <- all_attempts[all_attempts$status=="complete",]
  captures <- Map(function(path,engine) suite_read(path,engine=engine),attempts$directory,attempts$engine)
  names(captures) <- ifelse(attempts$workflow=="durable",attempts$engine,attempts$workflow)
  ref <- if(is.null(reference)) captures$ledgr else reference$native$ledgr
  stopifnot(!is.null(ref))
  controls <- lapply(seq_len(nrow(all_attempts)),function(i) {
    a <- all_attempts[i,]
    suite_books(a)
    x <- if(is.null(reference)) captures[[if(a$workflow=="durable") a$engine else a$workflow]] else
      if(a$workflow=="durable") reference$native[[a$engine]] else reference$workflows[[a$workflow]]
    control <- suite_control(x,bars,a$engine,a$workflow)
    if(a$status=="complete") for(arm in c("cold","warm")) {
      native <- suite_read(a$directory,arm,a$engine)
      fields <- if(a$workflow=="durable") c("fills","equity","holdings") else c("equity","closed_trades")
      stopifnot(identical(control,suite_control(native,bars,a$engine,a$workflow)),
        all(vapply(fields,function(field) identical(x[[field]],native[[field]]),logical(1L))))
      if(a$engine=="ledgr") stopifnot(identical(native$identity$run_id,paste0("suite_",arm,
        if(grepl("_N",shape)) paste0("_",sprintf("%04d",a$requested)) else "")))
      if(a$engine=="ledgr" && a$workflow!="durable") stopifnot(native$identity$returned_pulses==length(unique(bars$ts_utc)),native$identity$t_engine>0,
        identical(control,suite_control(ref,bars,"ledgr",a$workflow)))
    }
    data.frame(key=paste(required$lane[1L],shape,a$engine,a$workflow,sep=":"),control=control)
  })
  comparisons <- do.call(rbind,lapply(setdiff(attempts$engine[attempts$workflow=="durable"],"ledgr"),function(peer)
    data.frame(engine=peer,shape=shape,suite_compare(ref,captures[[peer]],bars,peer),ratio_eligible=FALSE)))
  controls <- do.call(rbind,controls)
  attr(controls,"comparisons") <- comparisons
  if(shape!="12x90") return(controls)
  native <- captures[attempts$engine[attempts$workflow=="durable"]]
  workflows <- captures[c("ephemeral","spot_fifo")]
  executed <- stats::setNames(rep(1L,length(native)),names(native))
  executed[["ledgr"]] <- 3L
  record <- list(id=id,date=as.character(Sys.Date()),product="891c23c8",assignments=assignments,
    comparisons=comparisons,coverage=suite_coverage(assignments,comparisons,executed),timings=data.frame(),memory=data.frame(),bars=bars,workflows=workflows,
    qualification_controls=vapply(names(native),function(engine) suite_control(native[[engine]],bars,engine),""),
    workflow_provenance=attempts[attempts$workflow!="durable",],provenance=data.frame(engine=names(native),
      native_directory=attempts$directory[attempts$workflow=="durable"],reset_identical=TRUE,qualification_only=TRUE),native=native)
  suite_validate(record,id)
  record
}

# Lossless financial projection: capture container/type differences do not change values.
suite_financial <- function(native,bars,engine) {
  fills <- native$fills[c("ts_utc","instrument_id","qty","price","fee")]
  fills$instrument_id <- as.character(fills$instrument_id)
  for(name in c("qty","price","fee")) fills[[name]] <- as.numeric(fills[[name]])
  stamps <- sort(unique(suite_stamp(bars$ts_utc)))
  equity <- native$equity[match(stamps,native$equity$ts_utc),c("ts_utc","cash","equity")]
  stopifnot(!anyNA(equity),all(fills$fee==0),all(equity$cash>=0))
  for(name in c("cash","equity")) equity[[name]] <- as.numeric(equity[[name]])
  rownames(fills) <- rownames(equity) <- NULL
  list(fills=fills,equity=equity,holdings=suite_positions(native,bars,engine=="zipline"))
}
suite_control <- function(native,bars,engine,workflow="durable") {
  if(workflow=="durable") return(digest::digest(suite_financial(native,bars,engine),algo="sha256"))
  equity <- native$equity[c("ts_utc","equity")]
  equity$ts_utc <- suite_stamp(equity$ts_utc)
  trades <- native$closed_trades[c("close_ts_utc","realized_pnl")]
  trades$close_ts_utc <- suite_stamp(trades$close_ts_utc)
  rownames(equity) <- rownames(trades) <- NULL
  digest::digest(list(equity=equity,closed_trades=trades),algo="sha256")
}
suite_measure <- function(record,raw,controls,inputs,lane="headline") {
  attempts <- do.call(rbind,lapply(raw,function(path) jsonlite::fromJSON(file.path(path,"attempts.json"))))
  stopifnot(!anyDuplicated(attempts$id),all(attempts$mode=="measure"))
  timings <- memory <- equities <- lifecycle <- list()
  books <- partial <- list()
  shapes <- unique(attempts$shape)
  bar_inputs <- stats::setNames(lapply(shapes,function(shape) read.csv(file.path(inputs,paste0(sub("_N[0-9]+$","",shape),".csv")))),shapes)
  for(i in seq_len(nrow(attempts))) {
    a <- attempts[i,]
    key <- paste(lane,a$shape,a$engine,a$workflow,sep=":")
    ref <- controls[controls$key==key,]
    stopifnot(nrow(ref)==1L)
    if(grepl("_N",a$shape)) books[[a$id]] <- suite_books(a)
    phase_path <- file.path(dirname(a$directory),paste0(a$id,".phases.csv"))
    if(file.exists(phase_path) && file.info(phase_path)$size>0) {
    phases <- read.csv(phase_path)
    phases$key <- key
    phases$id <- a$id
    phases$engine <- a$engine
    phases$workflow <- a$workflow
    phases$shape <- a$shape
    memory[[length(memory)+1L]] <- phases
    }
    if(a$status!="complete") {
      path <- file.path(a$directory,"timing.json")
      if(file.exists(path)) partial[[a$id]] <- jsonlite::fromJSON(path)
      next
    }
    stopifnot(grepl("8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c",a$power_plan),
      a$affinity==65535)
    bars <- bar_inputs[[a$shape]]
    clocks <- jsonlite::fromJSON(file.path(a$directory,"timing.json"))
    stopifnot(identical(clocks$arm,c("cold","warm")),all(clocks$clock_sec>0))
    if(grepl("_N",a$shape)) stopifnot(all(clocks$requested==a$requested),all(clocks$completed==a$requested))
    for(j in seq_len(nrow(clocks))) {
      clock <- clocks[j,]
      native <- suite_read(a$directory,clock$arm,a$engine)
      if(a$engine=="ledgr") {
        lifecycle[[a$id]][[clock$arm]] <- native$identity
        stopifnot(identical(native$identity$run_id,paste0("suite_",clock$arm,
          if(grepl("_N",a$shape)) paste0("_",sprintf("%04d",a$requested)) else "")))
        if(a$workflow=="durable") stopifnot(native$identity$state_rows==length(unique(bars$ts_utc))) else
          stopifnot(native$identity$returned_pulses==length(unique(bars$ts_utc)),native$identity$t_engine>0)
      }
      if(a$repetition==1L && j==1L && a$workflow=="durable") equities[[a$engine]] <- native$equity
      actual <- suite_control(native,bars,a$engine,a$workflow)
      stopifnot(identical(actual,ref$control[[1L]]))
      timings[[length(timings)+1L]] <- data.frame(key=key,id=a$id,engine=a$engine,workflow=a$workflow,
        shape=a$shape,repetition=a$repetition,arm=clock$arm,clock_sec=clock$clock_sec,
        iteration_sec=clock$iteration_sec,outputs=clock$outputs,native_control=actual)
    }

  }
  required <- record$assignments[record$assignments$lane==lane,]
  combined <- suite_rows(record$attempts,attempts)
  selected <- combined[combined$shape %in% required$shape,]
  slots <- table(paste(selected$shape,selected$engine,selected$workflow))
  stopifnot(setequal(names(slots),paste(required$shape,required$engine,required$workflow)),
    all(as.integer(slots)==ifelse(grepl("^1166x7200 ",names(slots)),1L,5L)))
  record$attempts <- suite_rows(record$attempts,attempts)
  record$controls <- suite_rows(record$controls,controls)
  record$lifecycle <- c(record$lifecycle,lifecycle)
  record$books <- c(record$books,books)
  record$partial_clocks <- c(record$partial_clocks,partial)
  record$timings <- suite_rows(record$timings,do.call(rbind,timings))
  record$memory <- suite_rows(record$memory,do.call(rbind,memory))
  record$comparisons <- suite_rows(record$comparisons,attr(controls,"comparisons"))
  c <- record$comparisons
  a <- record$attempts
  counts <- table(paste(a$shape,a$engine,a$workflow)[a$status=="complete"])
  eligible <- names(counts)[counts==5L]
  c$ratio_eligible <- c$shape!="1166x7200" & c$agreement=="same trades and balances" &
    paste(c$shape,c$engine,"durable") %in% eligible & paste(c$shape,"ledgr","durable") %in% eligible
  record$comparisons <- c
  measured <- a[a$root_pid>0,]
  executed <- 1L+vapply(names(record$native),function(engine)
    nrow(unique(measured[measured$engine==engine,c("shape","workflow")])),integer(1L))
  executed[["ledgr"]] <- executed[["ledgr"]]+2L
  record$coverage <- suite_coverage(record$assignments,c,executed)
  if(lane=="headline") {
  if(is.null(equities$ledgr)) equities$ledgr <- suite_read(a$directory[which(a$engine=="ledgr" & a$workflow=="durable" & a$shape=="500x1260" & a$status=="complete")[1L]])$equity
  reference <- equities$ledgr
  updated <- do.call(rbind,lapply(names(equities),function(engine) {
    x <- equities[[engine]][match(reference$ts_utc,equities[[engine]]$ts_utc),]
    data.frame(engine=engine,final_equity=tail(x$equity,1L),profit=tail(x$equity,1L)-1e7,
      final_equity_difference=tail(x$equity-reference$equity,1L),
      max_equity_difference=max(abs(x$equity-reference$equity)),max_cash_difference=max(abs(x$cash-reference$cash)))
  }))
  record$financial <- suite_rows(if(is.null(record$financial)) NULL else record$financial[!record$financial$engine %in% names(equities),],updated)
  }
  record$measurement_directory <- raw
  record$date <- as.character(Sys.Date())
  suite_validate(record,record$id)
  record
}
