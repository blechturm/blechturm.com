"""Documented vectorbt core/Numba next-open signals, shared cash, native results."""
import numpy as np
import pandas as pd
import vectorbt as vbt
from vectorbt.portfolio.enums import OrderSide

REUSE = "unchanged native OHLC frames; fresh MA calculations and Portfolio per arm; warmed Numba kernels"

def prepare(bars, out):
    frames = {name: bars.pivot(index="ts_utc", columns="instrument_id", values=name).sort_index(axis=1)
              for name in ("open", "close")}
    assert all(np.isfinite(frame.to_numpy()).all() for frame in frames.values())
    return frames

def run(prepared, trace=False, delay=1):
    close, opening = prepared["close"], prepared["open"]
    fast = vbt.MA.run(close, window=5, ewm=False, engine="numba").ma
    slow = vbt.MA.run(close, window=10, ewm=False, engine="numba").ma
    fast.columns = slow.columns = close.columns
    above = fast > slow
    usable = fast.notna() & slow.notna() & fast.shift(1).notna() & slow.shift(1).notna()
    entries = usable & above & ~above.shift(1, fill_value=False)
    exits = usable & ~above & above.shift(1, fill_value=False)
    # Native documented next-open recipe: signal at close t, execute open t+1.
    portfolio = vbt.Portfolio.from_signals(
        close, entries.shift(delay, fill_value=False), exits.shift(delay, fill_value=False),
        price=opening, size=1.0, size_type="amount", direction="longonly",
        init_cash=1e7, cash_sharing=True, group_by=True, call_seq="default",
        fees=0.0, fixed_fees=0.0, slippage=0.0, accumulate=False,
        allow_partial=False, raise_reject=True, engine="numba")
    orders = portfolio.orders.records
    fills = pd.DataFrame(dict(ts_utc=close.index.take(orders.idx.to_numpy()),
        instrument_id=close.columns.take(orders.col.to_numpy()),
        qty=np.where(orders.side.to_numpy()==OrderSide.Buy, orders["size"], -orders["size"]),
        price=orders.price, fee=orders.fees))
    equity = pd.DataFrame(dict(ts_utc=close.index, cash=portfolio.cash().to_numpy(),
                              equity=portfolio.value().to_numpy()))
    holdings = portfolio.assets().rename_axis(index="ts_utc",columns="instrument_id")
    holdings = holdings.reset_index().melt(id_vars="ts_utc",var_name="instrument_id",value_name="qty")
    if trace: rows, cols = np.where((entries | exits).to_numpy())
    scores = pd.DataFrame(dict(ts_utc=np.tile(close.index,len(close.columns)),
        instrument_id=np.repeat(close.columns,len(close)),fast=fast.to_numpy().T.ravel(),slow=slow.to_numpy().T.ravel())) if trace else None
    intent = pd.DataFrame(dict(ts_utc=close.index.take(rows),instrument_id=close.columns.take(cols),
                              target=entries.to_numpy()[rows,cols].astype(float))) if trace else None
    return dict(fills=fills,equity=equity,holdings=holdings,scores=scores,intent=intent)
