# Scaling launch stop: preserve the completed cases

Runtime957c818a:31 complete processes/62 actual clocks; the final vectorbt
stress worker never launched because its task-owned TEMP launcher disappeared.
The base Python remains present. Available Defender/Security/PowerShell logs
do not attribute the deletion; Sysmon telemetry is unavailable. The maintainer
is not aware of cleanup or fault tests. No claim identifies the deleting actor.

Original attempts/unexpected_error metadata remains unchanged. The old
controller dropped the failing row before writing session metadata; the
executor_disposition records that known launch failure and a conservative
490-second controller-wall budget debit, not a performance clock. Source
324b8deb catches Process.Start errors and preserves failed/unrun rows. Its
actual missing-executable gut has one failed/one unrun and zero workers.

Keep all31 completed cases, including every ordinary repeat, and validate
their native controls. A stable non-TEMP exact-pin runtime is prepared before
requalification and the one never-executed stress observation. No completed
case is repeated, selected by speed or silently replaced. The original
launch failure remains separate history. Whole WS5/review stays open.
