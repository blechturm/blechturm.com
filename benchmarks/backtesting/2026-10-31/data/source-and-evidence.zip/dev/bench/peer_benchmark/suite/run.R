entered <- as.numeric(Sys.time())
entered_elapsed <- proc.time()[["elapsed"]]
file <- sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value=TRUE)[1L])
here <- dirname(normalizePath(file,winslash="/"))
source(file.path(here,"../dense/native.R"))
out <- dense_arg("out")
if(dir.exists(out)) stop("worker output must be new")
dir.create(out,recursive=TRUE)
phase <- function(name) writeLines(name,file.path(out,"phase.txt"))
phase("import")
engine <- dense_arg("engine")
.libPaths(c(dense_arg("library"),if(engine=="ledgr") .libPaths() else .Library),include.site=engine=="ledgr")
workflow <- dense_arg("workflow","durable")
iterations <- as.integer(dense_arg("iterations","1"))
stopifnot(length(iterations)==1L,!is.na(iterations),iterations>=1L)
package <- switch(engine,ledgr="ledgr",pmwr="PMwR",quantstrat="quantstrat")
suppressPackageStartupMessages(library(package,character.only=TRUE))
source(file.path(here,if(engine=="ledgr") "ledgr.R" else paste0("r_peers/",engine,".R")))
invisible(compiler::enableJIT(3L))
imported <- proc.time()[["elapsed"]]
phase("input")
input <- if(engine=="ledgr") dense_arg("input") else read.csv(dense_arg("input"))
if(engine!="ledgr") input$ts_utc <- as.POSIXct(input$ts_utc,format="%Y-%m-%dT%H:%M:%SZ",tz="UTC")
input_end <- proc.time()[["elapsed"]]
phase("preparation")
prepared <- suite_prepare(input,out)
prep_end <- proc.time()[["elapsed"]]
timing <- list()
seen <- character()
for (arm in c("cold","warm")) {
  if(arm=="warm") {
    invisible(gc())
    phase("retained")
    Sys.sleep(0.6)
  }
  phase(arm)
  start <- proc.time()[["elapsed"]]
  results <- vector("list",iterations)
  book_rows <- list()
  for(iteration in seq_len(iterations)) {
    reused <- engine=="ledgr" && arm=="warm" && identical(dense_arg("gut"),"reuse")
    run_label <- if(arm=="warm" && identical(dense_arg("gut"),"completed")) "suite_cold" else paste0("suite_",arm)
    if(iterations>1L) run_label <- paste0(run_label,"_",sprintf("%04d",iteration))
    result <- if(reused) suite_run(prepared,trace=FALSE,opening_cash=prior_cash,run_id=run_label) else
      if(engine=="ledgr") suite_run(prepared,trace=identical(dense_arg("trace"),"true"),workflow=workflow,run_id=run_label) else
      suite_run(prepared,trace=identical(dense_arg("trace"),"true"))
    if(engine=="ledgr") {
      if(workflow=="durable") stopifnot(result$identity$state_rows==nrow(result$equity)) else
        stopifnot(result$identity$t_engine>0,result$identity$returned_pulses==nrow(result$equity))
      if(result$identity$run_id %in% seen) stop("Completed-run reuse detected")
      seen <- c(seen,result$identity$run_id)
    }
    results[[iteration]] <- result
    book_rows[[iteration]] <- data.frame(iteration=iteration,
      run_id=if(engine=="ledgr") result$identity$run_id else run_label,
      engine_sec=if(engine=="ledgr" && workflow!="durable") result$identity$t_engine else NA_real_,financial_identical=NA)
    if(iterations>1L) write.table(book_rows[[iteration]],file.path(out,paste0(arm,"_books.csv")),
      sep=",",row.names=FALSE,col.names=iteration==1L,append=iteration>1L)
  }
  finish <- proc.time()[["elapsed"]]
  phase("record")
  fields <- if(workflow=="durable") c("fills","equity","holdings") else c("equity","closed_trades")
  economic <- lapply(results,function(x) x[fields])
  books <- do.call(rbind,book_rows)
  books$financial_identical <- vapply(economic,identical,logical(1L),economic[[1L]])
  if(iterations>1L) write.csv(books,file.path(out,paste0(arm,"_books.csv")),row.names=FALSE)
  stopifnot(nrow(books)==iterations,all(books$financial_identical))
  rm(results,economic)
  timing[[arm]] <- list(arm=arm,workflow=workflow,requested=iterations,completed=nrow(books),
    clock_sec=if(arm=="cold") entered-as.numeric(dense_arg("launch"))+finish-entered_elapsed else finish-start,
    startup_sec=if(arm=="cold") entered-as.numeric(dense_arg("launch")) else NULL,
    import_sec=if(arm=="cold") imported-entered_elapsed else NULL,
    input_sec=if(arm=="cold" && engine!="ledgr") input_end-imported else NULL,
    preparation_sec=if(arm=="cold") prep_end-input_end else NULL,
    iteration_sec=finish-start,pid=Sys.getpid(),outputs=if(workflow=="durable") "fills;equity;cash;asset_holdings" else "equity;closed_trade_pnl")
  jsonlite::write_json(unname(timing),file.path(out,"timing.json"),auto_unbox=TRUE,digits=NA,pretty=TRUE)
  saveRDS(result,file.path(out,paste0(arm,"_native.rds")),compress=FALSE,version=3L)
  prior_cash <- tail(result$equity$cash,1L)
  rm(result)
}
phase("validation")
if(engine=="ledgr" && workflow=="durable") for(arm in c("cold","warm"))
  suite_validate_terminal(prepared,readRDS(file.path(out,paste0(arm,"_native.rds"))))
phase("complete")
writeLines(c(paste("JIT:",compiler::enableJIT(3L)),capture.output(sessionInfo())),
  file.path(out,"environment.txt"))
