"""Native adapter entry point; no fills, funding or accounting implementation."""
import argparse
import csv
import importlib.util
import json
import os
import sys
import time
from pathlib import Path

ENTERED = time.time()
ENTRY_MONOTONIC = time.perf_counter()
HERE = Path(__file__).resolve().parent
sys.path = [x for x in sys.path if Path(x or ".").resolve() != HERE]

def main():
    parser = argparse.ArgumentParser()
    for key in ("engine", "input", "out", "launch"):
        parser.add_argument("--" + key, required=True)
    parser.add_argument("--trace", action="store_true")
    parser.add_argument("--iterations", type=int, default=1)
    parser.add_argument("--probe", choices=["terminal", "retention", "retention-gut"])
    args = parser.parse_args()
    if args.iterations < 1:
        parser.error("iterations must be positive")
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=False)
    def phase(name):
        (out / "phase.txt").write_text(name, encoding="utf-8")
    phase("import")
    import pandas as pd
    spec = importlib.util.spec_from_file_location("native_adapter", HERE / (args.engine + ".py"))
    adapter = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = adapter
    spec.loader.exec_module(adapter)
    imported = time.perf_counter()
    phase("input")
    bars = pd.read_csv(args.input, float_precision="round_trip")
    bars["ts_utc"] = pd.to_datetime(bars.ts_utc, utc=True)
    input_end = time.perf_counter()
    if args.probe=="terminal":
        adapter.terminal_probe(bars,out)
        return
    phase("preparation")
    prepared = adapter.prepare(bars, out)
    prep_end = time.perf_counter()
    times = []
    for arm in ("cold", "warm"):
        if arm == "warm":
            import gc
            gc.collect()
            if args.probe in ("retention", "retention-gut"):
                retained = cold_equity() is not None
                (out / "retention_probe.json").write_text(json.dumps(dict(cold_capture_retained=retained)), encoding="utf-8")
                if retained:
                    raise RuntimeError("Cold result retained before warm execution")
            phase("retained")
            time.sleep(0.6)
        phase(arm)
        start = time.perf_counter()
        results, books = [], []
        progress = out / (arm + "_books.csv")
        for iteration in range(1, args.iterations + 1):
            result = adapter.run(prepared, trace=args.trace)
            results.append(result)
            book = dict(iteration=iteration, run_id=f"suite_{arm}_{iteration:04d}", financial_identical="")
            books.append(book)
            if args.iterations > 1:
                with progress.open("w" if iteration == 1 else "a", newline="", encoding="utf-8") as stream:
                    writer = csv.DictWriter(stream, fieldnames=book)
                    if iteration == 1:
                        writer.writeheader()
                    writer.writerow(book)
        finish = time.perf_counter()
        times.append(dict(arm=arm, requested=args.iterations, completed=len(books), clock_sec=ENTERED-float(args.launch)+finish-ENTRY_MONOTONIC if arm=="cold" else finish-start,
                          import_sec=imported-ENTRY_MONOTONIC if arm=="cold" else None,
                          startup_sec=ENTERED-float(args.launch) if arm=="cold" else None,
                          input_sec=input_end-imported if arm=="cold" else None,
                          preparation_sec=prep_end-input_end if arm=="cold" else None,
                          iteration_sec=finish-start, pid=os.getpid(), outputs="fills;equity;cash;asset_holdings"))
        (out / "timing.json").write_text(json.dumps(times, indent=2), encoding="utf-8")
        phase("record")
        for book, native in zip(books, results):
            book["financial_identical"] = all(native[name].equals(results[0][name]) for name in ("fills", "equity", "holdings"))
        if args.iterations > 1:
            with progress.open("w", newline="", encoding="utf-8") as stream:
                writer = csv.DictWriter(stream, fieldnames=books[0])
                writer.writeheader()
                writer.writerows(books)
        if not all(book["financial_identical"] for book in books):
            raise RuntimeError("Independent session books changed native financial results")
        for name, frame in result.items():
            if frame is not None:
                frame.to_csv(out / (arm+"_"+name+".csv"), index=False, float_format="%.17g")
        # Serialization is outside the clock; no indicator payload or old book enters warm.
        if arm == "cold" and args.probe in ("retention", "retention-gut"):
            import weakref
            cold_equity = weakref.ref(result["equity"])
            if args.probe == "retention-gut":
                kept_cold = result
        del result, results, native, frame
        # Backtrader inspects caller frames; refresh its cached locals after deletion.
        locals()
    phase("complete")
    (out / "timing.json").write_text(json.dumps(times, indent=2), encoding="utf-8")
    import importlib.metadata as metadata
    (out / "environment.json").write_text(json.dumps(dict(python=sys.version,
        packages={d.metadata["Name"]: d.version for d in metadata.distributions()},
        reuse=adapter.REUSE,threads={k:os.environ.get(k) for k in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS","NUMBA_NUM_THREADS","PYTHONHASHSEED")}), indent=2), encoding="utf-8")

if __name__ == "__main__":
    main()
