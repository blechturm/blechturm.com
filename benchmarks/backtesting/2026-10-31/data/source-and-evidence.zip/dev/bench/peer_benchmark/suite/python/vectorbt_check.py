"""Optional two-framework native diff/check; no execution or accounting substitute."""
import argparse
import hashlib
import importlib.util
import json
import subprocess
import sys
import warnings
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
sys.path = [x for x in sys.path if Path(x or ".").resolve() != HERE]
import numpy as np
import pandas as pd
import rdata
warnings.filterwarnings("ignore", message="Missing constructor for R class.*", category=UserWarning)
INPUTS = Path("C:/Users/maxth/AppData/Local/Temp/ledgr-peer-suite-cut3-normalized-inputs")
PROTECTED = ["R", "src", "tests", "NAMESPACE", "DESCRIPTION", "man", "inst/design"]

def scope():
    return subprocess.check_output(["git", "-C", str(ROOT), "diff", "HEAD", "--binary", "--", *PROTECTED])

def read(path, engine, arm="cold"):
    if engine=="pmwr":
        result = rdata.read_rds(path / (arm+"_native.rds"))
    else:
        result = {p.stem.removeprefix(arm+"_"): pd.read_csv(p,float_precision="round_trip")
                  for p in path.glob(arm+"_*.csv")}
    for key, frame in result.items():
        if frame is None: continue
        frame = frame.reset_index(drop=True)
        if "ts_utc" in frame:
            frame["ts_utc"] = pd.to_datetime(frame.ts_utc,unit="s",utc=True) if engine=="pmwr" else pd.to_datetime(frame.ts_utc,utc=True)
        if "ts_utc" in frame: frame["ts_utc"] = frame.ts_utc.dt.as_unit("ns")
        if "instrument_id" in frame: frame["instrument_id"] = frame.instrument_id.astype(str)
        if key=="holdings" and "instrument_id" not in frame:
            frame = frame.melt(id_vars="ts_utc",var_name="instrument_id",value_name="qty")
        if key=="fills": frame = frame.sort_values("ts_utc",kind="stable").reset_index(drop=True)
        result[key] = frame
    return result

def control(native):
    digest = hashlib.sha256()
    for key, columns in [("fills",["ts_utc","instrument_id","qty","price","fee"]),
                         ("equity",["ts_utc","cash","equity"]),("holdings",["ts_utc","instrument_id","qty"])]:
        frame = native[key][columns].copy()
        for column in columns:
            if column=="ts_utc": frame[column]=pd.to_datetime(frame[column],utc=True).dt.as_unit("ns")
            elif column!="instrument_id": frame[column]=frame[column].astype(float)
        digest.update(pd.util.hash_pandas_object(frame,index=False).to_numpy().tobytes())
    return digest.hexdigest()

def compare(a,b,bars):
    times = pd.DatetimeIndex(sorted(bars.ts_utc.unique()))
    ids = sorted(bars.instrument_id.unique())
    def align(frame):
        assert not frame.duplicated(["ts_utc","instrument_id"]).any()
        return frame.set_index(["ts_utc","instrument_id"]).sort_index()
    def targets(frame):
        return frame.pivot(index="ts_utc",columns="instrument_id",values="target").reindex(index=times,columns=ids).ffill().fillna(0).iloc[:-1].to_numpy()
    sa,sb = align(a["scores"]),align(b["scores"])
    assert sa.index.equals(sb.index)
    x,y = sa[["fast","slow"]].to_numpy(float),sb[["fast","slow"]].to_numpy(float)
    u=2**-53
    gamma=lambda k:k*u/(1-k*u)
    score_bound=gamma(8*len(times)+64)*max(1,bars.close.abs().max())
    assert not np.isinf(x).any() and not np.isinf(y).any()
    masks=np.array_equal(np.isnan(x),np.isnan(y))
    scores=masks and np.all(np.abs(x-y)[np.isfinite(x)] <= (score_bound+8*u*np.maximum(np.abs(x),np.abs(y)))[np.isfinite(x)])
    above=np.array_equal(x[:,0]>x[:,1],y[:,0]>y[:,1])
    intent=np.array_equal(targets(a["intent"]),targets(b["intent"]))
    fa,fb=a["fills"],b["fills"]
    keys=fa[["ts_utc","instrument_id"]].equals(fb[["ts_utc","instrument_id"]])
    quantity=keys and np.array_equal(fa.qty.to_numpy(),fb.qty.to_numpy())
    price=quantity and np.all(np.abs(fa.price.to_numpy()-fb.price.to_numpy())<=8*u+8*u*np.maximum(np.abs(fa.price),np.abs(fb.price)))
    pa,pb=align(a["holdings"]),align(b["holdings"])
    assert np.isin(pa.qty,[0,1]).all() and np.isin(pb.qty,[0,1]).all()
    holdings=pa.index.equals(pb.index) and np.array_equal(pa.qty,pb.qty)
    ea,eb=a["equity"].set_index("ts_utc"),b["equity"].set_index("ts_utc")
    assert ea.index.equals(eb.index) and len(ea)==len(times)
    assert np.isfinite(ea.to_numpy()).all() and np.isfinite(eb.to_numpy()).all()
    assert (ea.cash>=0).all() and (eb.cash>=0).all() and (fa.fee==0).all() and (fb.fee==0).all()
    held=pb.qty.groupby(level="ts_utc").sum().max()
    bound=gamma(8*len(fb)+8*held+64)*(1e7+np.abs(fb.qty*fb.price).sum()+np.abs(eb.equity-eb.cash).max())
    balances=np.all(np.abs(ea.to_numpy()-eb.to_numpy())<=bound+8*u*np.maximum(np.abs(ea.to_numpy()),np.abs(eb.to_numpy())))
    full=scores and above and intent and quantity and price and holdings and balances
    return dict(score_agreement=bool(scores),max_score_difference=float(np.nanmax(np.abs(x-y))),score_bound=score_bound,
        intent_agreement=bool(intent and above),fill_keys=keys,quantity_agreement=quantity,reported_price_agreement=bool(price),
        holdings_agreement=holdings,balance_agreement=bool(balances),balance_bound=bound,
        max_equity_difference=float(np.abs(ea.equity-eb.equity).max()),max_cash_difference=float(np.abs(ea.cash-eb.cash).max()),
        agreement="same trades and balances" if full else "same decisions only" if scores and above and intent else "classified residual")

def report(path, timing, comparison, attempts):
    import matplotlib.pyplot as plt
    summary=timing.groupby(["engine","arm"]).seconds.agg(["count","median","min","max"])
    summary=summary.reindex(pd.MultiIndex.from_product([["pmwr","vectorbt"],["cold","warm"]],names=["engine","arm"]))
    summary["count"]=summary["count"].fillna(0).astype(int)
    summary.to_csv(path/"summary.csv",float_format="%.17g")
    warm=summary.xs("warm",level="arm")
    fig,axis=plt.subplots(figsize=(7,2.4),layout="constrained")
    for i,(name,row) in enumerate(warm.iterrows()):
        if pd.notna(row["median"]):
            axis.errorbar(row["median"],i,xerr=[[row["median"]-row["min"]],[row["max"]-row["median"]]],fmt="o",capsize=4)
            axis.annotate(f'{row["median"]:.4f}s (n={int(row["count"])})',(row["median"],i),xytext=(6,8),textcoords="offset points")
    axis.set(yticks=[0,1],yticklabels=["PMwR","vectorbt / Numba"],xlabel="Warm seconds, median and min/max",ylim=(-0.5,1.5))
    axis.margins(x=0.5)
    fig.savefig(path/"warm.svg")
    plt.close(fig)
    statuses={str(k):int(v) for k,v in pd.Series([a["status"] for a in attempts]).value_counts().items()}
    orders=[tuple(a["engine"] for a in attempts if a["repetition"]==rep and a["status"]=="complete") for rep in sorted({a["repetition"] for a in attempts})]
    orders=[order for order in orders if len(order)==2]
    order_note=("No complete two-framework repetition: observed ordering is unavailable." if not orders else
                "Counterbalanced two-framework ordering is present." if len(set(orders))>1 else
                f"Non-counterbalanced observations: {orders[0][0]} ran first in every complete repetition. Do not infer a PMwR trace-cleanup speedup from these clocks.")
    lines=["---",'title: "PMwR and vectorbt: a matched-rule probe"',"format:","  html:","    embed-resources: true","---","",
        "**Provisional internal evidence; see the record README for independent review and suite integration status.**", "", order_note, "",
        "500 instruments,1,260 daily bars; native SMA5/10 transition, one share, USD10 million shared cash, zero costs. Both recipes execute next open and materialize native fills, equity, cash and full holdings.","",
        "![Warm research time](warm.svg)" if not timing.empty else "**No valid timing observations: the host guard stopped this window.**","","| Framework | Clock | Valid pairs | Median s | Min s | Max s |","|---|---|---:|---:|---:|---:|"]
    for (engine,arm),row in summary.iterrows():
        lines.append(f'| {engine} | {arm} | {row["count"]} | {row["median"]:.4f} | {row["min"]:.4f} | {row["max"]:.4f} |')
    lines += ["","## Native result agreement","",f'Classification: **{comparison["agreement"]}**. Native reported execution prices agree: **{comparison["reported_price_agreement"]}**.',
        f'Maximum equity difference: USD{comparison["max_equity_difference"]:.10g}; maximum cash difference: USD{comparison["max_cash_difference"]:.10g}. Holdings agree: {comparison["holdings_agreement"]}; decisions agree: {comparison["intent_agreement"]}.',"",
        "PMwR1.3-0 reports closing prices in this recipe journal while its open-execution wealth agrees. This discrepancy remains visible; no trade-equivalent speed ratio or universal winner is claimed.","",
        "## Clock and scope","","Cold includes launch/imports, CSV parsing, native preparation, first-use compilation and required results. Warm includes fresh indicators, signals, independent portfolio construction/execution and all required outputs on prepared OHLC. Export and correctness checks are untimed. No prior signals or finished portfolio enter warm. Process-cold does not claim an empty OS or persistent Numba disk cache.","",
        "PMwR1.3-0/R4.6.1/TTR0.24.4 versus vectorbt1.2.0/Python3.12.13/Numba0.68.1; core Numba backend explicitly selected, optional Rust/PRO not measured. High performance,0xFFFF affinity, external math threads1; existing process-tree sampler/host guard. Raw attempts retain every invalid/unrun slot.","",
        f'Observed attempt statuses: {statuses}. This is an additional dense diagnostic; the required six-peer suite and WS4 missing repetitions are unchanged. Internal preliminary evidence, not a publication-ready suite claim.',"",
        "[Native vectorbt workflow](https://vectorbt.dev/getting-started/features/) | [Portfolio API](https://vectorbt.dev/api/portfolio/base/) | [PMwR btest](https://search.r-project.org/CRAN/refmans/PMwR/html/btest.html)"]
    (path/"report.md").write_text("\n".join(lines),encoding="utf-8")

def main():
    parser=argparse.ArgumentParser()
    for name in ("raw","out"): parser.add_argument("--"+name,type=Path,required=True)
    parser.add_argument("--scratch",type=Path)
    parser.add_argument("--measure",type=Path)
    parser.add_argument("--gut",action="store_true")
    args=parser.parse_args()
    before=scope()
    attempts=json.loads((args.raw/"attempts.json").read_text())
    assert len(attempts)==2 and all(a["status"]=="complete" for a in attempts)
    shape=attempts[0]["shape"]
    bars=pd.read_csv(INPUTS/(shape+".csv"),float_precision="round_trip")
    bars.ts_utc=pd.to_datetime(bars.ts_utc,utc=True)
    native={a["engine"]:read(Path(a["directory"]),a["engine"]) for a in attempts}
    controls={engine:control(value) for engine,value in native.items()}
    for a in attempts: assert controls[a["engine"]]==control(read(Path(a["directory"]),a["engine"],"warm"))
    comparison=compare(native["pmwr"],native["vectorbt"],bars)
    args.out.mkdir(parents=True,exist_ok=False)
    pd.DataFrame([comparison]).to_csv(args.out/"comparison.csv",index=False,float_format="%.17g")
    (args.out/"controls.json").write_text(json.dumps(controls,indent=2))
    if args.scratch:
        subprocess.run(["powershell","-NoProfile","-File",str(HERE.parent/"run_suite.ps1"),"-Mode","qualify",
            "-DiagnosticPair","vectorbt","-QualifyShape",shape,"-VectorbtPython",sys.executable,"-Out",str(args.scratch)],check=True)
        for engine in native:
            actual=read(args.scratch/(shape+"_"+engine+"_01"),engine)
            for field in ("fills","equity","holdings","scores","intent"):
                pd.testing.assert_frame_equal(native[engine][field],actual[field],check_dtype=False,check_exact=True)
        (args.out/"diff.csv").write_text("engine,field,difference\n")
    if args.gut:
        spec=importlib.util.spec_from_file_location("native_vectorbt",HERE/"vectorbt.py")
        adapter=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(adapter)
        prepared=adapter.prepare(bars,args.out)
        normal=adapter.run(prepared,trace=True)
        bad=adapter.run(prepared,trace=True,delay=0)
        assert control(normal)==controls["vectorbt"] and control(bad)!=controls["vectorbt"]
        bad["fills"].to_csv(args.out/"gut_same_bar_fills.csv",index=False,float_format="%.17g")
    if args.measure:
        measured=json.loads((args.measure/"attempts.json").read_text())
        assert len(measured)==10 and {a["engine"] for a in measured}=={"pmwr","vectorbt"}
        rows=[]
        for a in measured:
            if a["status"]!="complete": continue
            assert a["affinity"]==65535 and "8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c" in a["power_plan"]
            clocks=json.loads((Path(a["directory"])/"timing.json").read_text())
            assert [c["arm"] for c in clocks]==["cold","warm"]
            for c in clocks:
                assert c["clock_sec"]>0 and c["outputs"]=="fills;equity;cash;asset_holdings"
                assert control(read(Path(a["directory"]),a["engine"],c["arm"]))==controls[a["engine"]]
                rows.append(dict(engine=a["engine"],repetition=a["repetition"],arm=c["arm"],seconds=c["clock_sec"]))
        timing=pd.DataFrame(rows,columns=["engine","repetition","arm","seconds"])
        timing["seconds"]=pd.to_numeric(timing.seconds)
        timing.to_csv(args.out/"timings.csv",index=False,float_format="%.17g")
        report(args.out,timing,comparison,measured)
        (args.out/"attempts.json").write_text(json.dumps(measured,indent=2))
    assert before==scope(),"Protected package/design scope changed during check"
    print(json.dumps(comparison,indent=2))
    print("PASS: within-engine cold/warm controls; requested native scratch/gut/measurement checks")

if __name__=="__main__":
    main()
