# Native quantstrat registrations; blotter owns transactions and valuation.
suite_prepare <- function(bars,out) {
  frames <- split(bars,factor(bars$instrument_id,levels=sort(unique(bars$instrument_id),method="radix")))
  FinancialInstrument::currency("USD")
  lapply(names(frames),function(id) {
    FinancialInstrument::stock(id,currency="USD",multiplier=1)
    frame <- frames[[id]]
    x <- xts::xts(as.matrix(frame[c("open","high","low","close","volume")]),order.by=frame$ts_utc)
    colnames(x) <- paste0(id,c(".Open",".High",".Low",".Close",".Volume"))
    assign(id,x,envir=.GlobalEnv)
  })
  frames
}
suite_cross <- function(label,data=mktdata,direction) {
  above <- data[,"SMA.fast"] > data[,"SMA.slow"]
  prior <- lag(above)
  value <- !is.na(above) & !is.na(prior) & above != prior & above == direction
  value[is.na(value)] <- FALSE
  colnames(value) <- "transition"
  value
}
suite_run <- function(prepared,trace=FALSE) {
  name <- "suite_transition"
  suppressWarnings(try(quantstrat::rm.strat(name),silent=TRUE))
  ids <- names(prepared)
  times <- prepared[[1L]]$ts_utc
  start <- min(times)-86400
  blotter::initPortf(name,symbols=ids,initDate=start,currency="USD")
  blotter::initAcct(name,portfolios=name,initDate=start,initEq=1e7,currency="USD")
  quantstrat::initOrders(name,initDate=start)
  strategy <- quantstrat::strategy(name)
  strategy <- quantstrat::add.indicator(strategy,"SMA",list(x=quote(quantmod::Cl(mktdata)),n=5),label="fast")
  strategy <- quantstrat::add.indicator(strategy,"SMA",list(x=quote(quantmod::Cl(mktdata)),n=10),label="slow")
  assign("suite_cross",suite_cross,envir=.GlobalEnv)
  strategy <- quantstrat::add.signal(strategy,"suite_cross",list(direction=TRUE),label="enter")
  strategy <- quantstrat::add.signal(strategy,"suite_cross",list(direction=FALSE),label="exit")
  strategy <- quantstrat::add.rule(strategy,"ruleSignal",list(sigcol="transition.enter",sigval=TRUE,
    orderqty=1,ordertype="market",orderside="long",TxnFees=0,prefer="Open",replace=FALSE),type="enter")
  strategy <- quantstrat::add.rule(strategy,"ruleSignal",list(sigcol="transition.exit",sigval=TRUE,
    orderqty="all",ordertype="market",orderside="long",TxnFees=0,prefer="Open",replace=FALSE),type="exit")
  quantstrat::applyStrategy(strategy,portfolios=name)
  blotter::updatePortf(name,Dates=times)
  blotter::updateAcct(name,Dates=times)
  blotter::updateEndEq(name,Dates=times)
  portfolio <- blotter::getPortfolio(name)
  account <- blotter::getAccount(name)
  fills <- do.call(rbind,lapply(ids,function(id) {
    x <- portfolio$symbols[[id]]$txn
    x <- x[x[,"Txn.Qty"]!=0,]
    data.frame(ts_utc=zoo::index(x),instrument_id=id,qty=as.numeric(x[,"Txn.Qty"]),
      price=as.numeric(x[,"Txn.Price"]),fee=as.numeric(x[,"Txn.Fees"]))
  }))
  summary <- account$summary
  equity <- data.frame(ts_utc=zoo::index(summary),cash=as.numeric(summary$End.Eq-portfolio$summary$Net.Value),equity=as.numeric(summary$End.Eq))
  # Native daily posPL holds marked position quantities and market values.
  native_positions <- lapply(ids,function(id) portfolio$symbols[[id]]$posPL)
  scores <- if(trace) do.call(rbind,lapply(ids,function(id) {
    x <- quantstrat::applyIndicators(strategy,get(id,envir=.GlobalEnv))
    x <- quantstrat::applySignals(strategy,x)
    data.frame(ts_utc=zoo::index(x),instrument_id=id,fast=as.numeric(x[,"SMA.fast"]),slow=as.numeric(x[,"SMA.slow"]),
      enter=as.numeric(x[,"transition.enter"]),exit=as.numeric(x[,"transition.exit"]))
  }))
  list(fills=fills,equity=equity,holdings=do.call(rbind,lapply(seq_along(ids),function(i)
    data.frame(ts_utc=zoo::index(native_positions[[i]]),instrument_id=ids[i],native_positions[[i]],check.names=FALSE))),scores=scores)
}
