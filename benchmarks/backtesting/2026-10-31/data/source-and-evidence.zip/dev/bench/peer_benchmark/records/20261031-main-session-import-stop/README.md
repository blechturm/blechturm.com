# Main session import stop and retained-observation control

First N10 window: three R workflows completed, PyBroker failed importing
pandas/dateutil because six was missing from the older TEMP environment;
56 remaining slots are explicit unrun. All original metadata/stderr remains.
No native PyBroker book or performance clock existed. Elapsed49.2046729s
remains charged. The three completed observations and their native hashes
are retained, not rerun.

The same106 exact Python pins are installed as copies outside TEMP. Actual
PyBroker N10 both arms/book manifests match frozen financial controls. All
three retained R observations also match controls. Retained-control metadata
has exactly3 unchanged complete rows plus12 unrun and zero new workers.
Run remaining PyBroker observations separately, then remaining R observations
with CompletedAttempts pointing at this original window. Completed IDs are
skipped; all native source/directory/memory paths remain original. No finished
book is reused in a new experiment. Root cause of TEMP file removal remains
unattributed. No source rule/value/bound change or favourable resampling.
