# Cut 3 concrete source and detector allocation (accepted)

Accepted with cut 3 revision 2 by the maintainer on 2026-10-28. This is its
source allocation, not a second sequence. Dated amendments below own the
current caps; the initial allocation and earlier stop records remain history. `tickets.yml` owns every dependency
and acceptance condition. Workstreams4 and5 are reviewed and complete; later workstreams retain their allocated scope.
Maintainer, 2026-10-28: explicitly allowed the concrete 1639-line cumulative
R estimate to exceed the former 1500 allowance. The cut records an 1800-line
cap (161 reserve), not a per-file reset. No packing or moving R logic into
other languages to hide an overrun. An estimate/actual overrun still stops.

## Maintained R allocation

All helper/child, native extraction, provisioner, recipe and executable Qmd
source counts, wherever stored. Frozen record text is evidence, not a source
of executable helpers. Historical generation bodies remain at their named Git
revision; active files are migrated in place, never maintained as two engines.

| File | Planned physical lines | Responsibility |
| --- | ---: | --- |
| dense/check.R | 22 | Existing accepted helper/runner; counted in full. |
| dense/gut.R | 64 | Existing accepted helper/runner; counted in full. |
| dense/native.R | 249 | Existing accepted helper/runner; counted in full. |
| dense/recipes.R | 173 | Existing accepted helper/runner; counted in full. |
| dense/record.R | 11 | Existing accepted helper/runner; counted in full. |
| dense/timing.R | 124 | Existing accepted helper/runner; counted in full. |
| dense/timing_check.R | 152 | Existing accepted helper/runner; counted in full. |
| suite/records.R | 90 | Native extraction projection, fixed numeric bounds, first divergence; reuse dense_diff. |
| suite/run.R | 20 | Public native-row orchestration; process control stays in the existing/new PS launcher. |
| suite/check.R | 35 | Scratch record diff and shared corruption invocation; no second executor. |
| suite/ledgr.R | 25 | Public ledgr experiment/run/result adapter; reuse existing dense native readers. |
| suite/setup.R | 25 | Isolated pinned R peer provisioning; ordinary dependency metadata. |
| suite/r_peers/pmwr.R | 40 | Native callback/lifecycle/result extraction for qualification. |
| suite/r_peers/quantstrat.R | 70 | Native registration/lifecycle/orderbook result extraction. |
| suite/recipes/ledgr.R | 107 | Seven full authoring recipes/setup; historical physical source baseline 107 lines. |
| suite/recipes/pmwr.R | 77 | Seven full native recipes/setup; historical physical source baseline 77 lines. |
| suite/recipes/quantstrat.R | 200 | Seven native recipe registrations/custom rule/state/setup; no abbreviated hidden code. |
| suite/portfolio.R | 35 | Common portfolio input/selection and ledgr recipe; PyBroker native implementation in its Python source. |
| suite/pit.R | 30 | Coherent factual/survivor native scenario and result capture. |
| suite/geometry.R | 25 | Declared common price/key transformation and input funding envelope. |
| suite/authoring_counts.R | 15 | Source/setup line and conceptual-dependency input collection; human cold-read judgments stay labelled. |
| suite/generations.R | 30 | All-consumer migration inventory/dispatch and cross-generation comparisons; no compatibility engine. |
| peer_suite.qmd executable R chunks | 20 | Read accepted compact record and render figures/tables; includes all executable R. |
| **Total / cap / reserve** | **1639 / 1800 / 161** | Estimates are not permission to exceed the cap. |

The historical 184 ledgr/PMwR recipe lines are evidence for those two entries,
not a limit imposed on readability. Quantstrat has its own explicit 200-line
allocation. Shared setup is shown and counted as an indirection; it cannot
hide uncounted implementation. LDG-3139 checks the estimates against the
smallest runnable native interfaces before expected records. Material scope
changes stop for disposition; no automatic next allowance.

## Other executable/render source

| File group | Planned lines | Cap accounting |
| --- | ---: | --- |
| suite/python/backtrader.py | 230 | Native adapter and seven recipes/setup. |
| suite/python/bt.py | 230 | Native adapter and seven recipes/setup. |
| suite/python/zipline.py | 260 | Native bundle adapter and seven recipes/setup. |
| suite/python/pybroker.py | 250 | Native adapter, portfolio and seven recipes/setup. |
| suite/python/record_io.py and setup_check.py | 90 | Native interchange/setup checks; no R replacement engine. |
| **Python total / cap** | **1060 / 1200** | All child/helpers included. |
| existing dense/run_timing.ps1 | 157 | Inherited process launcher counted. |
| suite/run_suite.ps1 | 170 | Per-engine launch/counterbalance/time limits/collection. |
| suite/memory.ps1 | 160 | One descendant/phase memory sampler and native allocation witness. |
| suite/setup.ps1 | 60 | Isolated environment commands, no external service. |
| **PowerShell total / cap** | **547 / 650** | Includes inherited and new scripts. |
| peer_suite.qmd non-R markup/CSS | 350 | Cap450; executable R counted above. |

Dependency lockfiles, emitted records/logs and rendered HTML are ordinary
inputs/artifacts, not loopholes for executable logic. New helpers must be
assigned here before they are authored. Counts are reported at each close.

## Ten new seam-derived corruption detectors

Each control/fork runs before its expected data is frozen. These are shared
failure checks, not ten new expected-answer tables. Existing cut-2 detectors
remain intact. Native experimental assignments are bound by the cut matrix.

| Detector | Owning seam / source | Native failure to expose |
| --- | --- | --- |
| D1 | suite/records.R + check.R | Change a fill quantity/order key with aggregate equity unchanged. |
| D2 | suite/records.R + report input validator | Promote decision-only/residual output into an eligible ratio. |
| D3 | suite/ledgr.R + native adapters | Reuse prior book state in an actually executed warm callback. |
| D4 | suite/memory.ps1 | Omit a real allocating descendant from its engine/phase tree. |
| D5 | suite/portfolio.R + python/pybroker.py | Reverse native equal-score tie selection. |
| D6 | suite/pit.R | Remove/alter the survivor-selection hindsight distinction. |
| D7 | peer_suite.qmd + record validator | Use a different/implicit latest record from the explicit parameter. |
| D8 | report input validator | Remove a required peer from its coverage denominator. |
| D9 | suite/generations.R | Present stale WS4/WS8/WS5 evidence as the final generation. |
| D10 | retirement inventory/caller check | Leave a maintained legacy caller unmapped. |

Where two consumers use a validator they share its detector; none is hidden
in an uncounted script or called a row merely to evade the limit. Each lane's
inventory names its real rerun/diff/gut evidence and relevant shared detector.

## Complete WS5 migration ownership (LDG-3150)

Inventory every active consumer before migration: dense/recipes.R (including
historical rule semantics), dense/timing.R and its PS source selection;
suite ledgr/geometry/session/portfolio/PIT/authoring callbacks; feature-map,
params/state/schedule/opening/cost/experiment setup; public inspection/result
readers used for evidence; and executable report/article source consumers.
The inventory names old/new source generation, product revision, public API
replacement, owning rule, exact native-economic diff and permitted identity/
representation decisions. Seven authoring examples alone do not discharge it.

Old source runs only on its pinned old product. Current sources use accepted
WS5 APIs; no ctx$vec/state_prev/retired-reader fallback is restored on current
product. Historical first-state bodies and full oracle data stay at 2499dc58.
New generation records preserve all new source/config identities and compare
unchanged economics exactly; only already-decided owning-cut field changes
are allowed. The accepted all-consumer inventory and workstream-8 review are
hard prerequisites of LDG-3152. WS4 reruns may use their correct old generation
before WS5; WS8 final runs must use the fully migrated one.

## Workstream 4 implementation allocation check

The minimal native interfaces have now executed for all six peers. Current
maintained R plus executable report chunks: 1265 lines before measurement
collection; remaining unimplemented recipe/portfolio/PIT/count/generation
allocations total494. Combined current forecast1759, under1800 with41 reserve.
The larger worker and comparator use reserve; no helper is omitted, packed,
or moved to another language to evade the cap. Measure collection/session
extensions must fit the remaining reserve or stop for disposition. Python
and PowerShell remain below their cumulative caps. Final close records actuals.

## Budget disposition needed after the added ephemeral workflows (2026-10-29)

Maintained R including executable Qmd chunks is now1277 lines (795 inherited).
The existing future recipe/portfolio/PIT/count/generation allocation is494.
The remaining concrete work through workstream5 needs these source allocations:

| Existing allocated file | Additional forecast | Remaining responsibility |
| --- | ---: | --- |
| suite/records.R | 43 | Collect measured repetitions/phase memory and compare real timed native outputs with validation before ratios. |
| suite/check.R | 24 | Clock/host/partial-row checks and exact canonical/spot-FIFO retained-output checks and guts. |
| suite/run.R | 8 | Execute/count independent native session iterations and retain per-iteration economic controls. |
| peer_suite.qmd executable R | 6 | Compact measured-time/memory figures and financial-difference magnitude. |
| **Completion forecast** | **81** | Existing files only, no hidden helper. |

Full-cut forecast:1277+81+494=1852, above the accepted1800 cap. Current source
has not exceeded the cap. Further implementation stops for maintainer disposition
under cut3 scope_and_budget. Proposed revised cap2000 gives148 reserve against
this forecast. Other language caps and measurement limits stay unchanged.
This is a proposal, not an accepted allowance. No check is dropped or packed to
fit1800. The added public ephemeral/spot-FIFO rows were requested by the maintainer;
they retain equity/returns and closed-trade PnL, and are separate workflow diagnostics.

Maintainer disposition,2026-10-29: explicitly allowed2000 R lines. The1852
forecast and148 reserve are now accepted; implementation may resume. Earlier
1800-cap figures above are the historical cut allocation. All new workflow
rows, per-process capture code and executable report code remain counted.

Pre-measurement checkpoint: cumulative R including executable Qmd is1381;
Python346; PowerShell409 including inherited157. Native
control/clock collection now lives in the already allocated records.R and
check.R. The494-line future-lane allocation still counts: combined R
forecast1875 before the remaining session/check/report additions,
under the accepted2000 cap. No source or frozen cut2 witness is excluded.

## Maintainer-requested speed diagnosis,2026-10-29

Question: which measured work explains the warm ledgr/bt/PMwR gap on the
unchanged headline rule? Reuse the installed products, common fixture and
existing adapters. Separate profiles are diagnostic, never replacement
benchmark samples; no product optimization or measured-window retry.
Allocate suite/diagnose.R at most70 R lines and suite/python/diagnose.py at
most100 Python lines for runner, exact-output checker and the shared changed-
fill gut. Current1381+70+494 future-lane allocation=1945 R lines, leaving55
under the accepted2000 cap before the remaining session/check/report work.
The new files wrap existing native adapters; they do not own execution or
accounting. Stop on a changed financial control. Outputs live in a new named
temporary directory; one-page findings cite those executed records.

Diagnosis close actuals: R1455 including12 executable Qmd lines, Python439,
PowerShell409. Existing future-lane R allocation494 remains counted, giving1949
before the remaining session/check/report estimate38; forecast1987/reserve13.
Diagnostic R is65 lines and its Python runner93. Budget stops remain binding.
The extra native run-identity assertions are in already allocated adapters,
worker and records.R. No source is excluded and no product path is changed.

## WS4 corrected completion forecast

The completed speed diagnostic is preserved at7c6984e1 and its two executable
files are retired from the maintained harness. Its fresh-book corruption is
now in the shared checker. This retires an answered research probe; it does
not hide active source in a record or another language. Reproduction uses its
named historical source, not a compatibility path in current product code.

Current cumulative R1498 includes38 executable Qmd lines; Python346;
PowerShell520; non-R Qmd155. The remaining full-cut allocation494 is
unchanged. Forecast another8 session lines:2000 R/reserve0 under2000. The
corrected collector/checker already consume the earlier measurement-check
allocation. All changes remain in previously allocated current suite files;
actual/forecast overrun still stops. The retired diagnostic had65 R/93 Python
lines at its source checkpoint and remains inspectable there.


## WS4 review correction round1

The ordinary19-package dependency CSV now supplies exact native archive URLs
in dependency order; setup.R installs every row into an explicit temporary
library and validates all versions once. R peer workers exclude user/site
libraries. This replaces incomplete ambient checks, without another installer
framework or an executable helper hidden in metadata. Existing sampler source
owns a real foreign-R preflight/postflight preservation witness; the exact-
second epoch formatter and report ratio validator are repaired in place.
The redundant final timing JSON rewrite is removed; each completed arm still
persists its clock before native export. The failed Windows binary-basename
provisioning trial is retained; a new complete isolated restore and native
scratch diff pass. Current cumulative R1498 (38 Qmd), Python346, PS520,
non-R Qmd155; future494+8 gives2000/reserve0. No source cap is reset.


## Maintainer-requested optional vectorbt/PMwR dense measurement,2026-10-29

The maintainer requested a vectorbt measurement specifically against PMwR.
This is a bounded additional dense diagnostic, not an expansion of the six
required peers/five lanes/105 assignments or a waiver of WS4's missing clocks.
Cheaper prerequisite: the documented native vectorbt next-open unit transition
recipe must execute and expose the same decision/wealth/holding facts; any
native output difference remains classified. No claimed winner is preselected.

Allocate suite/python/vectorbt.py at most110 Python lines for that native
adapter and suite/python/vectorbt_check.py at most200 for scratch native diff,
within-engine controls, the real changed-execution gut and compact evidence.
Reuse record_io.py and the existing sampler/launcher; at most15 additional PS
lines select an explicit optional two-framework diagnostic. Ordinary separate
Python dependency lock is data; no shared measured environment is mutated.
Current346+310 forecast656 Python under1200; PS520+15 under650. R stays1498
and its full-cut forecast2000 unchanged. The existing dense240-minute budget
continues with prior work charged; stop on failed native qualification, host
violation or limits. No favourable automatic retry, product change, new R
helper, required-assignment edit or public performance claim.


### Optional diagnostic STOP: full Python forecast correction

The initial optional allocation counted only current Python source. That was
incomplete: original planned Python1060 minus existing346 leaves714 lines of
already planned peer-recipe/helper work. Current575 includes the new45-line
adapter and184-line checker. Full actual-based forecast575+714=1289 exceeds
the accepted1200 cap; the optional310-line allocation estimate would give1370.
Implementation/review/timing retry stop pending maintainer disposition. A1400
cap is requested, not assumed; R2000 and all other limits stay unchanged.
No code is hidden, packed, reclassified or prematurely retired to evade this.

The new controlled window also stopped after its first PMwR pair because
postflight background load was1.484 cores (limit1). One host_invalid plus
nine unrun slots are retained; there are no valid timing observations and no
automatic retry. This source-budget stop and the independent host-window
question remain open. Native small/large qualifications and sensitive scratch/
gut evidence remain available; they do not close measurement or review.


Maintainer then explicitly authorized retrying the existing measurement on
2026-10-29. One new window at source6abce650 completed five pairs for each
framework,20 exact within-engine validated arm clocks, with no guard changes
or failures. This execution-only instruction is not interpreted as a1400-line
Python-cap amendment; integration/implementation review still wait for that
source-budget disposition. No additional source/helper was written. The
original failed window and cumulative charges are preserved separately.


## Maintainer disposition,2026-10-29: Python cap2000

The maintainer explicitly directed "python also gets 2K". The cumulative
Python allowance is now2000 lines, including native adapters, helpers,
children and the remaining planned suite work. This supersedes the original
1200 cap and the unaccepted request for1400; neither is the active cap.
The recorded full-cut forecast1289 leaves711 lines reserve. Even the
optional allocation's conservative1370 estimate fits, with630 reserve.
The Python source-budget stop is cleared for review/integration to proceed.

R remains a separate2000-line cumulative cap. PowerShell650 and non-R
markup450 remain unchanged. No packing, hidden helpers, inherited-code
exemptions or automatic budget resets are introduced. Host checks, timing
windows/cumulative charges, no automatic retries, native-economic validation,
independent reviews and external-claim readiness remain binding. The required
six peers/five lanes/105 assignments and ticket/workstream numbers do not
change. This records budget authority, not acceptance of pending review or
completion of the missing WS4 timing record.


Optional review correction actuals: seven added Python report lines give582
current plus714 remaining planned =1296 full forecast,704 reserve under2000.
The current report and generator expose the discovered PMwR-first ordering
and actual attempt counts. Independent scoped review passes; cumulative
dense timing allowance and the missing main headline evidence remain open
as recorded in records/20261029-native-csv/README.md.


Host-policy redesign,2026-10-30: modify only existing suite/run_suite.ps1,
memory.ps1, records.R and python/vectorbt_check.py plus documentation. No
new helper/module or native adapter. The two background vetoes become
annotations, using PID/creation identities; power/owned-tree affinity stay
hard requirements. Existing hostwitness now proves idle R is accepted and
recorded at pre/post boundaries; its owned sleep jobs exit naturally. The
fixture expectation changes because the maintainer deliberately changed the
host policy, not to conceal a product failure. Source counts remain within
R2000/Python2000/PowerShell650; the actuals are recorded with the probe.


Host correction close actuals: R1498 including38 executable report lines,
full forecast2000; Python582/full1296; PowerShell536/650. One existing
pipeline filters positive CPU increments after independent review. No new
helper, hidden source, budget reset or changed required assignment.
cut3_host_guard_review.md accepts this correction only; full WS4 awaits
new headline evidence.


WS5 qualification reuses existing geometry.R and run_suite.ps1. Include the
two declared research workflows during scaling qualification as well as
measurement. The generator retains full-precision input-bound terms in an
ordinary RDS sidecar, replacing its rounded console summary; input values/
transforms do not change. Existing output-directory creation moves before
that write. Both edits add zero physical source lines; no new helper.


WS5 observed sampler correction stays in memory.ps1/run_suite.ps1: missing
CIM creation time reproduced a null method failure after nine native cells.
Record observation gaps and reject reused identities, with the expected root
birth passed from its actual process handle. lifetimewitness in the existing
sampler provides control/gut/recovery; unexpected observer errors retain
stack context. Existing native adapters/inputs are unchanged. PowerShell
actuals and remaining-session estimate stay below650; R remains1498/full2000.


## WS5 resumption and completion forecast, 2026-10-31 (proposed)

The maintainer resumed WS5, including deferred measurements and sessions.
The existing frozen product and native adapters stay fixed; unrelated host
processes are observed and left alone. No new timing window has started.
The saved geometry outputs are being checked using the existing native
financial projection and predeclared peer comparator, before new controls.

Recount: maintained R1498 including38 executable Qmd lines; Python582;
PowerShell589. Existing unimplemented recipe/portfolio/PIT/count/generation
allocation remains494 R lines. The former session estimate of8 lines does
not cover actual completion counts, independently identified books, per-book
financial reset checks and partial-batch evidence. The collector also still
assumes the seven-peer headline matrix and exactly five repeats everywhere;
it cannot accept the existing shape assignments or descriptive stress case.

Concrete additional completion allocation, all in already allocated files:

| Existing file | Additional R forecast | Remaining work |
| --- | ---: | --- |
| suite/run.R | 30 | Execute actual N books per arm; retain observed completion/identity records and per-book financial reset checks; preserve partial progress. Supersedes the old8-line estimate. |
| suite/records.R | 60 | Reuse native projections for geometry/session controls, append lane records, validate shape/N lifecycle and declared ordinary/stress repetitions. |
| suite/check.R | 18 | Scratch rerun/diff and shared changed-book/count/ratio guts for the new lane. |
| peer_suite.qmd executable R | 12 | Separate shape/session timing and phase-memory panels, actual counts and bounded outcomes. |
| **Total** | **120** | No new R helper, engine, packing or hidden source. |

Full-cut forecast1498+120+494=2112 exceeds the accepted2000 R cap by112.
Proposed cumulative cap2300 leaves188 reserve against this concrete forecast.
This is a request, not an accepted allowance; implementation and new timing
windows stop for maintainer disposition. No existing gate/recipe is retired
to manufacture room. Current maintained R is still1498.

Native Python record_io.py session execution/count/control capture adds at
most45 lines:582+45+714 existing future allocation=1341, within2000.
Existing run_suite.ps1 session dispatch/observed progress and budgets adds at
most45 lines:589+45=634, within650. No R responsibility moves to Python.
Non-R report text remains within450. The600-minute lane budget and all
native economics, fixed numeric bounds, no-retry and independent-review
requirements stay unchanged. No product file or frozen oracle changes.


## Maintainer disposition, 2026-10-31: R cap2300

The maintainer explicitly accepted the proposed cumulative2300 R cap.
The forecast stop is resolved. All earlier caps/stop records remain history;
no timing, Python2000, PowerShell650 or non-R Qmd450 limit changes.

Before authoring, refine completion allocations within the accepted reserve:
suite/run.R +45; suite/records.R +100; suite/check.R +35; executable Qmd +20.
These replace the preceding120-line forecast, not add to it. Current1498 +
200 remaining WS5 +494 unchanged future =2192, reserve108 under2300.
The additional room makes observed per-book completion/identity/financial
checks, explicit bounded outcomes and scratch/gut/report code readable.
No new helper file, source exclusion, packing or language transfer is planned.
Python +45/full forecast1341 and PowerShell +45/forecast634 stay unchanged.
Implementation and measurements may resume against the frozen product.


WS5 pre-measurement checkpoint: actual R1628 including52 executable Qmd lines;
unchanged remaining future494 gives2122/reserve178 under2300. Python607 plus
future714 gives1321 under2000. PowerShell613 under650; non-R Qmd210 under450.
Current allocated files own all session/count/partial/gut/report extensions.
The real empty-phase fault and zero-prefix probe corrections are preserved
in qualification evidence; no product/frozen source or detector count changed.


WS5 cold-capture correction,2026-10-31: actual-worker inspection found a
Python cold capture retained by the post-batch validation loop and cached
frame locals. A stopped b385551e measurement window is retained in full;
no clock is promoted. Allocate another12 R lines in existing suite/check.R
for the shared D3 actual-worker weak-reference control/gut; existing
record_io.py +15 Python lines stays within its additional45 allocation.
run_suite.ps1 +2 lines supports an explicit after-current-worker StopFile,
within the existing additional45 PS allocation. No product, fixture,
financial bound or native recipe changes. R forecast remains below2300;
actual counts are recorded again after the exercised correction.

The retention stop preserves26 completed/one explicit before-work stop/53
unrun slots, with no promoted clocks or killed process. The control/gut is
executed against the actual worker; source cleanup is outside timed native
calls. Corrected measurement starts from a new committed source and charges
the stopped window plus120 correction seconds. See records/20261031-ws5-
retention-stopped/README.md; native inputs/economics/controls stay unchanged.


## Maintainer-requested PMwR shape coverage, 2026-10-31

The maintainer explicitly requires PMwR on every WS5 shape. Add the missing
20x23400 and1166x7200 assignments:107 required rows, up from105. Existing
PMwR ordinary/session rows already cover the other shapes. Qualify the two
additions, then five ordinary repeats and one descriptive stress process,
with the pinned native adapter, unchanged inputs/results and shared sampler.
Allocate suite/pmwr_shapes.R at most70 R lines for native qualification,
exact cold/warm financial diff and the existing changed-fill gut; existing
collector/checker gain at most5 R lines for two raw measured windows and
the explicit amended assignment map. Existing PS adds at most3 lines for
an explicit shape selector; ordinary/stress repetition rules stay unchanged.
Current1640 R plus75 and unchanged future494 forecasts2209/2300. Python
is unchanged; PS616+3 forecasts619/650. No source is excluded or packed.
Qualification/measurement charge the existing600-minute ledger. The
in-flight d68ac43d window keeps its original80 slots/source; its worker
and sampler bytes remain unchanged. New PMwR windows use a newly committed
source, after the in-flight window to avoid self-contention. New collection
combines disjoint assignments, retaining each native directory/source and
original metadata. It never replaces old clocks or repeats a covered case.
Independent WS5 review includes this maintainer-amended coverage.


WS5 final evidence integration allocation,2026-10-31: reserve another12 R
lines in existing check.R,4 in records.R and4 executable Qmd lines. This
attaches the entire withdrawn-source attempt/clock set to the final record
and folded report, rejects clock promotion, and makes existing zero-clock
and insufficient-repeat guts predicate-specific. The zero-clock gut now
changes one observed value rather than destroying the table schema; the
repeat gut first validates the otherwise-consistent partial record, including
session books. This strengthens D1/D2, with no product/oracle change or new
detector. Current1692 plus20 and unchanged future494 forecasts2206/2300.
One extra Qmd line beyond its earlier +20 forecast comes from this reserve;
remaining future-lane allocation494 is unchanged. No timing worker, adapter,
sampler or required economic output changes.


## Accepted vectorbt quantitative-only extension, 2026-10-31

Maintainer accepts vectorbt as seventh regular peer for native qualification,
headline/all four timing shapes, cold/warm, N10/100/1000 independent sessions
and process-tree memory. Add nine required assignments:116 total. Portfolio
state checks concern the existing crossover: cash/equity/holdings/decisions,
with reported fill prices classified separately. Rotation, seven authoring
recipes, custom stateful callbacks and PIT capability are expressly deferred.
No RFC/product semantic change or new native adapter. Existing vectorbt1.2.0
Numba adapter and isolated environment stay pinned. Actual N10 prerequisite
returns10 independent books per arm, exactly matches the reviewed five native
surfaces and releases its cold result. Fresh12x90/500x1260 pair qualification
also executes; expected financial controls are frozen only after checking.

Amend the existing native-qualification role, not add a parallel framework:
rename/extend suite/pmwr_shapes.R (51 lines) to pair_qualification.R, at most
120 R lines. Reuse primary native projections/comparator/book checker and
changed-fill gut. It augments the existing record with vectorbt, retains old
valid PMwR clocks as unpooled history, and supplies ordinary RDS/JSON controls
to the existing collector. Allocate records.R +8, check.R +4 and executable
Qmd +4 R lines; PS launcher +10 for isolated environment, pair/shape selection
and distinct attempt prefixes. Python native code stays unchanged. Forecast:
1709-51+120+8+4+4+494 unchanged future =2288/2300; reserve12. PS618+10=628/650;
Python619+714 unchanged future=1333/2000. Stop on a forecast/actual overrun.

Fresh ordinary paired windows alternate PMwR-first/vectorbt-first; do not
pool historical always-PMwR-first clocks. Five repeats give3/2 first-position
counts; stress stays one descriptive observation, with order disclosed and
no ratio. Existing non-PMwR observations stay intact. Main session windows
run the other four workflows; paired session windows run PMwR/vectorbt.
Old headline/scaling PMwR clocks remain visible as valid historical evidence
superseded solely for the maintainer-requested balanced cohort. No framework
failure, outlier deletion, favourable retry or forced price parity.

Existing source caps and dense21600/scaling36000-second cumulative allowances
stay fixed, with prior qualification/measurement/debugging/verification
charged. Independent WS5 close review includes the amendment and explicit
portfolio-state/fill-price fields. No external claim or extra authoring/PIT
obligation is inferred. Native qualification and real feasible measurements
precede prose; resource limits keep honest completion counts/statuses.

Before completing collection, transfer the unused check.R +4 allocation to
records.R: +12 records.R, +0 check.R, +4 Qmd. The2288 forecast is unchanged.
This keeps existing non-PMwR headline financial rows while adding paired
PMwR/vectorbt rows against the same executed ledgr reference. No native
workflow or comparison bound changes.


Observed launch/import losses,2026-10-31: current PS630 after preserving
Process.Start failures. Allocate at most14 further PS lines, forecasting644
under650, to retain previously complete metadata and skip those exact IDs
when finishing the remaining R session observations. This reuses actual
measurements, not finished books in a new timing call. Runtime/phase/source
paths stay original, elapsed time charges only new work, and old window
elapsed remains in the prior debit. Failed/unrun rows remain history.
No new helper, native adapter, R line or time allowance.


Maintainer curtailment,2026-10-31: stop remaining N1000 ledgr repeats after
the active durable repetition3, using the existing StopFile. Retain all
complete observations and explicit operator-unrun slots with actual counts.
The standard/scaling matrix and completed peer batches stay intact. No
worker is terminated or completed observation repeated. Native code/source
allocations and the600-minute allowance do not change; the proposed660-minute
extension is unnecessary. Independent WS5 review and rendered report follow.


WS5 close,2026-10-31: independent clean-context Codex Type1 PASS at1ce7b507,
first invocation/no corrections. Actual R1788 including62 executable Qmd
lines +494 future =2282/2300; Python619+714 future=1333/2000; PS642/650;
non-R Qmd266/450. Future allocations are unchanged. Report and235 complete
processes/470 clocks preserve seven maintainer-curtailed N1000 repeats.
The independent rerun/gut/diff, raw clocks/books/memory, restored pins and
offline render pass. Source/product/frozen paths stay unchanged.
